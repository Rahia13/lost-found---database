# Ctrl+HER — Lost & Found Intelligence System

DBMS project prototype (CSE 3522). Plain HTML/CSS/JS, no frameworks or backend.

## Files
- `index.html` — page structure and markup
- `styles.css` — dark navy/light-blue theme, layout, components
- `script.js` — app state, the 16-entity data model, matching engine,
  routing, and all view rendering

## Running it
Just open `index.html` in a browser — no build step, no server required.
(Opening it directly via `file://` works fine since it only uses
`localStorage`, not `fetch`.)

Data persists in the browser's `localStorage` under the key
`lostfound-db`, so reloading the page keeps your demo state. To reset
back to the seeded demo data, clear that key from your browser's dev
tools (Application → Local Storage) or open the page in a private/
incognito window.

## Demo login
The login screen has one-click buttons for three seeded accounts:
- Ayman Chowdhury (student)
- Farzana Rahman (student)
- Nusrat Jahan (staff/admin)

It's seeded with one complete case already carried through the full
lifecycle (lost report → found report → auto-match → claim → approval
→ handover → resolved), so the workflow can be shown immediately.

## Entity → table mapping
`script.js` keeps one array per entity in a single `DB` object, mirroring
the ER diagram:

`User, Category, Location, Storage, Camera, Lost_Report, Found_Report,
Match, Claim, Evidence, Investigation, Witness_Report, CCTV_Ref,
Custody_Event, Handover, Audit_Log`

Every user action (submitting a report, filing a claim, approving/
rejecting, opening an investigation, recording a handover) writes an
`Audit_Log` entry, visible under Staff & Admin → Audit Log.
