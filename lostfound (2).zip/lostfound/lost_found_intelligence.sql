-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 28, 2026 at 10:23 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lost_found_intelligence`
--

-- --------------------------------------------------------

--
-- Table structure for table `audit_log`
--

CREATE TABLE `audit_log` (
  `audit_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `action` varchar(100) NOT NULL,
  `table_name` varchar(100) DEFAULT NULL,
  `record_id` int(11) DEFAULT NULL,
  `action_description` varchar(255) DEFAULT NULL,
  `action_time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `audit_log`
--

INSERT INTO `audit_log` (`audit_id`, `user_id`, `action`, `table_name`, `record_id`, `action_description`, `action_time`) VALUES
(1, 3, 'Review Claim', 'claim', 3, 'Staff member reviewed the ownership claim for the reported laptop.', '2026-09-27 18:24:24');

-- --------------------------------------------------------

--
-- Table structure for table `camera`
--

CREATE TABLE `camera` (
  `camera_id` int(11) NOT NULL,
  `camera_name` varchar(100) NOT NULL,
  `location_id` int(11) NOT NULL,
  `camera_type` varchar(50) DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `description` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `camera`
--

INSERT INTO `camera` (`camera_id`, `camera_name`, `location_id`, `camera_type`, `status`, `description`) VALUES
(1, 'Main Gate Camera', 4, 'CCTV', 'active', 'Camera monitoring the university main entrance'),
(2, 'Library Camera', 2, 'CCTV', 'active', 'Camera monitoring the central library entrance'),
(3, 'Cafeteria Camera', 3, 'CCTV', 'active', 'Camera monitoring the cafeteria area'),
(4, 'Campus Camera', 1, 'CCTV', 'active', 'Camera covering the main campus area'),
(5, 'Bus Stop Camera', 5, 'CCTV', 'inactive', 'Camera near the university bus stop');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(100) NOT NULL,
  `description` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`category_id`, `category_name`, `description`) VALUES
(1, 'Electronics', 'Electronic devices such as phones, laptops and tablets'),
(2, 'Mobile Phone', 'Mobile phones and smartphones'),
(3, 'Laptop', 'Laptops and notebook computers'),
(4, 'Bags', 'Backpacks, handbags and other bags'),
(5, 'Documents', 'ID cards, certificates and other documents'),
(6, 'Accessories', 'Items such as watches, wallets and glasses');

-- --------------------------------------------------------

--
-- Table structure for table `cctv_ref`
--

CREATE TABLE `cctv_ref` (
  `cctv_ref_id` int(11) NOT NULL,
  `investigation_id` int(11) NOT NULL,
  `camera_id` int(11) NOT NULL,
  `footage_date` date NOT NULL,
  `start_time` time DEFAULT NULL,
  `end_time` time DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cctv_ref`
--

INSERT INTO `cctv_ref` (`cctv_ref_id`, `investigation_id`, `camera_id`, `footage_date`, `start_time`, `end_time`, `description`, `created_at`) VALUES
(1, 1, 4, '2026-09-20', '10:00:00', '10:30:00', 'CCTV footage from the campus camera reviewed for the reported laptop loss.', '2026-09-27 18:16:14');

-- --------------------------------------------------------

--
-- Table structure for table `claim`
--

CREATE TABLE `claim` (
  `claim_id` int(11) NOT NULL,
  `match_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `claim_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `claim_status` enum('pending','approved','rejected') DEFAULT 'pending',
  `claim_description` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `claim`
--

INSERT INTO `claim` (`claim_id`, `match_id`, `user_id`, `claim_date`, `claim_status`, `claim_description`) VALUES
(3, 4, 1, '2026-09-27 18:12:17', 'pending', 'This is my black Dell laptop. I can provide private evidence to verify ownership.');

-- --------------------------------------------------------

--
-- Table structure for table `custody_event`
--

CREATE TABLE `custody_event` (
  `custody_event_id` int(11) NOT NULL,
  `found_report_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `storage_id` int(11) DEFAULT NULL,
  `event_type` enum('received','moved','released') NOT NULL,
  `event_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `notes` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `custody_event`
--

INSERT INTO `custody_event` (`custody_event_id`, `found_report_id`, `user_id`, `storage_id`, `event_type`, `event_date`, `notes`) VALUES
(1, 1, 3, 1, 'received', '2026-09-27 18:17:24', 'Staff received the found laptop and placed it in the main storage room.');

-- --------------------------------------------------------

--
-- Table structure for table `evidence`
--

CREATE TABLE `evidence` (
  `evidence_id` int(11) NOT NULL,
  `claim_id` int(11) NOT NULL,
  `evidence_type` varchar(50) DEFAULT NULL,
  `evidence_description` varchar(255) DEFAULT NULL,
  `is_private` tinyint(1) DEFAULT 1,
  `submitted_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `evidence`
--

INSERT INTO `evidence` (`evidence_id`, `claim_id`, `evidence_type`, `evidence_description`, `is_private`, `submitted_at`) VALUES
(1, 3, 'Ownership Proof', 'Claimant can provide a unique identifying detail about the laptop that is not publicly visible.', 1, '2026-09-27 18:13:02');

-- --------------------------------------------------------

--
-- Table structure for table `found_report`
--

CREATE TABLE `found_report` (
  `found_report_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `location_id` int(11) NOT NULL,
  `found_date` date NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `status` enum('available','matched','claimed','closed') DEFAULT 'available',
  `storage_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `found_report`
--

INSERT INTO `found_report` (`found_report_id`, `user_id`, `item_id`, `location_id`, `found_date`, `description`, `status`, `storage_id`, `created_at`) VALUES
(1, 3, 1, 4, '2026-09-23', 'A black Dell laptop was found near the university main gate', 'available', 1, '2026-09-27 17:51:24'),
(2, 3, 2, 3, '2026-09-24', 'A blue Samsung mobile phone was found in the cafeteria', 'available', 2, '2026-09-27 17:51:24'),
(3, 2, 4, 2, '2026-09-25', 'A university ID card was found near the central library', 'available', 3, '2026-09-27 17:51:24');

-- --------------------------------------------------------

--
-- Table structure for table `handover`
--

CREATE TABLE `handover` (
  `handover_id` int(11) NOT NULL,
  `claim_id` int(11) NOT NULL,
  `handed_over_by` int(11) NOT NULL,
  `handed_over_to` int(11) NOT NULL,
  `handover_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `handover_status` enum('pending','completed','cancelled') DEFAULT 'pending',
  `notes` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `handover`
--

INSERT INTO `handover` (`handover_id`, `claim_id`, `handed_over_by`, `handed_over_to`, `handover_date`, `handover_status`, `notes`) VALUES
(1, 3, 3, 1, '2026-09-27 18:23:13', 'completed', 'Laptop handed over to the verified claimant after staff verification.');

-- --------------------------------------------------------

--
-- Table structure for table `investigation`
--

CREATE TABLE `investigation` (
  `investigation_id` int(11) NOT NULL,
  `claim_id` int(11) NOT NULL,
  `investigator_id` int(11) NOT NULL,
  `investigation_date` date NOT NULL,
  `investigation_status` enum('open','in_progress','completed','closed') DEFAULT 'open',
  `findings` varchar(500) DEFAULT NULL,
  `conclusion` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `investigation`
--

INSERT INTO `investigation` (`investigation_id`, `claim_id`, `investigator_id`, `investigation_date`, `investigation_status`, `findings`, `conclusion`, `created_at`) VALUES
(1, 3, 3, '2026-09-28', 'in_progress', 'The laptop description and identifying details provided by the claimant are consistent with the found laptop.', 'Further verification through CCTV and witness information is required.', '2026-09-27 18:14:57');

-- --------------------------------------------------------

--
-- Table structure for table `item`
--

CREATE TABLE `item` (
  `item_id` int(11) NOT NULL,
  `item_name` varchar(100) NOT NULL,
  `category_id` int(11) NOT NULL,
  `description` text DEFAULT NULL,
  `color` varchar(50) DEFAULT NULL,
  `brand` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `item`
--

INSERT INTO `item` (`item_id`, `item_name`, `category_id`, `description`, `color`, `brand`) VALUES
(1, 'Laptop', 3, 'Black laptop with a small scratch on the lid', 'Black', 'Dell'),
(2, 'Mobile Phone', 2, 'Android smartphone with a blue case', 'Blue', 'Samsung'),
(3, 'Backpack', 4, 'Medium sized backpack', 'Black', 'Nike'),
(4, 'ID Card', 5, 'University identification card', 'White', NULL),
(5, 'Wrist Watch', 6, 'Analog wrist watch', 'Silver', 'Casio'),
(6, 'Dell', 1, 'stickers', 'Black', 'Dell'),
(7, 'lenovo', 1, 'stickers', 'blue', 'lenovo'),
(8, 'lenovo', 1, 'stickers', 'blue', 'lenovo'),
(9, 'lenovo', 1, 'stickers', 'blue', 'lenovo'),
(10, 'lenovo', 1, 'blue', 'blue', 'lenovo'),
(11, 'lenovo', 1, 'ok', 'Black', 'lenovo');

-- --------------------------------------------------------

--
-- Table structure for table `location`
--

CREATE TABLE `location` (
  `location_id` int(11) NOT NULL,
  `location_name` varchar(150) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `location`
--

INSERT INTO `location` (`location_id`, `location_name`, `address`, `city`, `description`) VALUES
(1, 'University Campus', 'Main Campus Road', 'Dhaka', 'Main university campus area'),
(2, 'Central Library', 'Library Building, University Campus', 'Dhaka', 'University central library'),
(3, 'Cafeteria', 'Ground Floor, Student Center', 'Dhaka', 'Student cafeteria'),
(4, 'Main Gate', 'University Main Entrance', 'Dhaka', 'Main entrance of the campus'),
(5, 'Bus Stop', 'University Bus Stop', 'Dhaka', 'Public bus waiting area');

-- --------------------------------------------------------

--
-- Table structure for table `lost_report`
--

CREATE TABLE `lost_report` (
  `lost_report_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `location_id` int(11) NOT NULL,
  `lost_date` date NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `status` enum('open','matched','closed') DEFAULT 'open',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `lost_report`
--

INSERT INTO `lost_report` (`lost_report_id`, `user_id`, `item_id`, `location_id`, `lost_date`, `description`, `status`, `created_at`) VALUES
(4, 1, 1, 1, '2026-09-20', 'Lost a black Dell laptop near the main campus area', 'open', '2026-09-27 17:48:42'),
(5, 2, 2, 3, '2026-09-21', 'Lost a blue Samsung mobile phone in the cafeteria', 'open', '2026-09-27 17:48:42'),
(6, 1, 4, 2, '2026-09-22', 'Lost my university ID card near the central library', 'open', '2026-09-27 17:48:42');

-- --------------------------------------------------------

--
-- Table structure for table `match_record`
--

CREATE TABLE `match_record` (
  `match_id` int(11) NOT NULL,
  `lost_report_id` int(11) NOT NULL,
  `found_report_id` int(11) NOT NULL,
  `match_score` decimal(5,2) DEFAULT NULL,
  `match_reason` varchar(255) DEFAULT NULL,
  `status` enum('pending','confirmed','rejected') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `match_record`
--

INSERT INTO `match_record` (`match_id`, `lost_report_id`, `found_report_id`, `match_score`, `match_reason`, `status`, `created_at`) VALUES
(4, 4, 1, 95.00, 'Same laptop type, brand and similar description', 'pending', '2026-09-27 18:08:50');

-- --------------------------------------------------------

--
-- Table structure for table `notification`
--

CREATE TABLE `notification` (
  `notification_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `notification_type` varchar(50) DEFAULT NULL,
  `message` varchar(255) NOT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `notification`
--

INSERT INTO `notification` (`notification_id`, `user_id`, `notification_type`, `message`, `is_read`, `created_at`) VALUES
(1, 1, 'Match Found', 'A possible match has been found for your lost Dell laptop. Please review and submit a claim if applicable.', 0, '2026-09-27 18:26:07');

-- --------------------------------------------------------

--
-- Table structure for table `storage`
--

CREATE TABLE `storage` (
  `storage_id` int(11) NOT NULL,
  `storage_name` varchar(100) NOT NULL,
  `storage_location` varchar(255) DEFAULT NULL,
  `capacity` int(11) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `storage`
--

INSERT INTO `storage` (`storage_id`, `storage_name`, `storage_location`, `capacity`, `description`) VALUES
(1, 'Main Storage Room', 'Administration Building, Room 101', 100, 'Main storage area for found items'),
(2, 'Electronics Locker', 'Administration Building, Locker Section', 30, 'Secure storage for electronic devices'),
(3, 'Document Cabinet', 'Security Office', 50, 'Storage for found documents and ID cards');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('student','staff','admin') NOT NULL DEFAULT 'student',
  `phone` varchar(20) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `name`, `email`, `password`, `role`, `phone`, `created_at`) VALUES
(1, 'Ayesha Rahman', 'ayesha@example.com', 'password123', 'student', '01710000001', '2026-09-27 17:28:44'),
(2, 'Nabil Hasan', 'nabil@example.com', 'password123', 'student', '01710000002', '2026-09-27 17:28:44'),
(3, 'Sara Ahmed', 'sara@example.com', 'password123', 'staff', '01710000003', '2026-09-27 17:28:44'),
(4, 'Admin User', 'admin@example.com', 'admin123', 'admin', '01710000004', '2026-09-27 17:28:44');

-- --------------------------------------------------------

--
-- Table structure for table `witness_report`
--

CREATE TABLE `witness_report` (
  `witness_report_id` int(11) NOT NULL,
  `investigation_id` int(11) NOT NULL,
  `witness_name` varchar(100) NOT NULL,
  `witness_contact` varchar(50) DEFAULT NULL,
  `witness_statement` varchar(500) NOT NULL,
  `report_date` date NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `witness_report`
--

INSERT INTO `witness_report` (`witness_report_id`, `investigation_id`, `witness_name`, `witness_contact`, `witness_statement`, `report_date`, `created_at`) VALUES
(1, 1, 'Rahim Ahmed', '01710000005', 'I saw a student carrying a black laptop near the main campus area before it was reported missing.', '2026-09-28', '2026-09-27 18:15:13');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `audit_log`
--
ALTER TABLE `audit_log`
  ADD PRIMARY KEY (`audit_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `camera`
--
ALTER TABLE `camera`
  ADD PRIMARY KEY (`camera_id`),
  ADD KEY `location_id` (`location_id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`category_id`),
  ADD UNIQUE KEY `category_name` (`category_name`);

--
-- Indexes for table `cctv_ref`
--
ALTER TABLE `cctv_ref`
  ADD PRIMARY KEY (`cctv_ref_id`),
  ADD KEY `investigation_id` (`investigation_id`),
  ADD KEY `camera_id` (`camera_id`);

--
-- Indexes for table `claim`
--
ALTER TABLE `claim`
  ADD PRIMARY KEY (`claim_id`),
  ADD KEY `match_id` (`match_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `custody_event`
--
ALTER TABLE `custody_event`
  ADD PRIMARY KEY (`custody_event_id`),
  ADD KEY `found_report_id` (`found_report_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `storage_id` (`storage_id`);

--
-- Indexes for table `evidence`
--
ALTER TABLE `evidence`
  ADD PRIMARY KEY (`evidence_id`),
  ADD KEY `claim_id` (`claim_id`);

--
-- Indexes for table `found_report`
--
ALTER TABLE `found_report`
  ADD PRIMARY KEY (`found_report_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `item_id` (`item_id`),
  ADD KEY `location_id` (`location_id`),
  ADD KEY `storage_id` (`storage_id`);

--
-- Indexes for table `handover`
--
ALTER TABLE `handover`
  ADD PRIMARY KEY (`handover_id`),
  ADD KEY `claim_id` (`claim_id`),
  ADD KEY `handed_over_by` (`handed_over_by`),
  ADD KEY `handed_over_to` (`handed_over_to`);

--
-- Indexes for table `investigation`
--
ALTER TABLE `investigation`
  ADD PRIMARY KEY (`investigation_id`),
  ADD KEY `claim_id` (`claim_id`),
  ADD KEY `investigator_id` (`investigator_id`);

--
-- Indexes for table `item`
--
ALTER TABLE `item`
  ADD PRIMARY KEY (`item_id`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `location`
--
ALTER TABLE `location`
  ADD PRIMARY KEY (`location_id`);

--
-- Indexes for table `lost_report`
--
ALTER TABLE `lost_report`
  ADD PRIMARY KEY (`lost_report_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `item_id` (`item_id`),
  ADD KEY `location_id` (`location_id`);

--
-- Indexes for table `match_record`
--
ALTER TABLE `match_record`
  ADD PRIMARY KEY (`match_id`),
  ADD KEY `lost_report_id` (`lost_report_id`),
  ADD KEY `found_report_id` (`found_report_id`);

--
-- Indexes for table `notification`
--
ALTER TABLE `notification`
  ADD PRIMARY KEY (`notification_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `storage`
--
ALTER TABLE `storage`
  ADD PRIMARY KEY (`storage_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `witness_report`
--
ALTER TABLE `witness_report`
  ADD PRIMARY KEY (`witness_report_id`),
  ADD KEY `investigation_id` (`investigation_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `audit_log`
--
ALTER TABLE `audit_log`
  MODIFY `audit_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `camera`
--
ALTER TABLE `camera`
  MODIFY `camera_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `cctv_ref`
--
ALTER TABLE `cctv_ref`
  MODIFY `cctv_ref_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `claim`
--
ALTER TABLE `claim`
  MODIFY `claim_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `custody_event`
--
ALTER TABLE `custody_event`
  MODIFY `custody_event_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `evidence`
--
ALTER TABLE `evidence`
  MODIFY `evidence_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `found_report`
--
ALTER TABLE `found_report`
  MODIFY `found_report_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `handover`
--
ALTER TABLE `handover`
  MODIFY `handover_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `investigation`
--
ALTER TABLE `investigation`
  MODIFY `investigation_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `item`
--
ALTER TABLE `item`
  MODIFY `item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `location`
--
ALTER TABLE `location`
  MODIFY `location_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `lost_report`
--
ALTER TABLE `lost_report`
  MODIFY `lost_report_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `match_record`
--
ALTER TABLE `match_record`
  MODIFY `match_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `notification`
--
ALTER TABLE `notification`
  MODIFY `notification_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `storage`
--
ALTER TABLE `storage`
  MODIFY `storage_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `witness_report`
--
ALTER TABLE `witness_report`
  MODIFY `witness_report_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `audit_log`
--
ALTER TABLE `audit_log`
  ADD CONSTRAINT `audit_log_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`);

--
-- Constraints for table `camera`
--
ALTER TABLE `camera`
  ADD CONSTRAINT `camera_ibfk_1` FOREIGN KEY (`location_id`) REFERENCES `location` (`location_id`);

--
-- Constraints for table `cctv_ref`
--
ALTER TABLE `cctv_ref`
  ADD CONSTRAINT `cctv_ref_ibfk_1` FOREIGN KEY (`investigation_id`) REFERENCES `investigation` (`investigation_id`),
  ADD CONSTRAINT `cctv_ref_ibfk_2` FOREIGN KEY (`camera_id`) REFERENCES `camera` (`camera_id`);

--
-- Constraints for table `claim`
--
ALTER TABLE `claim`
  ADD CONSTRAINT `claim_ibfk_1` FOREIGN KEY (`match_id`) REFERENCES `match_record` (`match_id`),
  ADD CONSTRAINT `claim_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`);

--
-- Constraints for table `custody_event`
--
ALTER TABLE `custody_event`
  ADD CONSTRAINT `custody_event_ibfk_1` FOREIGN KEY (`found_report_id`) REFERENCES `found_report` (`found_report_id`),
  ADD CONSTRAINT `custody_event_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`),
  ADD CONSTRAINT `custody_event_ibfk_3` FOREIGN KEY (`storage_id`) REFERENCES `storage` (`storage_id`);

--
-- Constraints for table `evidence`
--
ALTER TABLE `evidence`
  ADD CONSTRAINT `evidence_ibfk_1` FOREIGN KEY (`claim_id`) REFERENCES `claim` (`claim_id`);

--
-- Constraints for table `found_report`
--
ALTER TABLE `found_report`
  ADD CONSTRAINT `found_report_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`),
  ADD CONSTRAINT `found_report_ibfk_2` FOREIGN KEY (`item_id`) REFERENCES `item` (`item_id`),
  ADD CONSTRAINT `found_report_ibfk_3` FOREIGN KEY (`location_id`) REFERENCES `location` (`location_id`),
  ADD CONSTRAINT `found_report_ibfk_4` FOREIGN KEY (`storage_id`) REFERENCES `storage` (`storage_id`);

--
-- Constraints for table `handover`
--
ALTER TABLE `handover`
  ADD CONSTRAINT `handover_ibfk_1` FOREIGN KEY (`claim_id`) REFERENCES `claim` (`claim_id`),
  ADD CONSTRAINT `handover_ibfk_2` FOREIGN KEY (`handed_over_by`) REFERENCES `user` (`user_id`),
  ADD CONSTRAINT `handover_ibfk_3` FOREIGN KEY (`handed_over_to`) REFERENCES `user` (`user_id`);

--
-- Constraints for table `investigation`
--
ALTER TABLE `investigation`
  ADD CONSTRAINT `investigation_ibfk_1` FOREIGN KEY (`claim_id`) REFERENCES `claim` (`claim_id`),
  ADD CONSTRAINT `investigation_ibfk_2` FOREIGN KEY (`investigator_id`) REFERENCES `user` (`user_id`);

--
-- Constraints for table `item`
--
ALTER TABLE `item`
  ADD CONSTRAINT `item_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `category` (`category_id`);

--
-- Constraints for table `lost_report`
--
ALTER TABLE `lost_report`
  ADD CONSTRAINT `lost_report_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`),
  ADD CONSTRAINT `lost_report_ibfk_2` FOREIGN KEY (`item_id`) REFERENCES `item` (`item_id`),
  ADD CONSTRAINT `lost_report_ibfk_3` FOREIGN KEY (`location_id`) REFERENCES `location` (`location_id`);

--
-- Constraints for table `match_record`
--
ALTER TABLE `match_record`
  ADD CONSTRAINT `match_record_ibfk_1` FOREIGN KEY (`lost_report_id`) REFERENCES `lost_report` (`lost_report_id`),
  ADD CONSTRAINT `match_record_ibfk_2` FOREIGN KEY (`found_report_id`) REFERENCES `found_report` (`found_report_id`);

--
-- Constraints for table `notification`
--
ALTER TABLE `notification`
  ADD CONSTRAINT `notification_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`);

--
-- Constraints for table `witness_report`
--
ALTER TABLE `witness_report`
  ADD CONSTRAINT `witness_report_ibfk_1` FOREIGN KEY (`investigation_id`) REFERENCES `investigation` (`investigation_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
