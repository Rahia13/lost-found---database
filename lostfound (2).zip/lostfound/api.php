<?php
/**
 * api.php — thin JSON API between script.js and the `lost_found_intelligence`
 * database. Put it next to index.html (e.g. C:\xampp\htdocs\lostfound\).
 *
 * script.js owns the logic; this file only (1) checks who is logged in,
 * (2) returns table rows the current user may see, and (3) inserts/updates
 * whitelisted columns of whitelisted tables.
 */
declare(strict_types=1);
session_start();
header('Content-Type: application/json; charset=utf-8');

/* ---- settings (XAMPP defaults) ---- */
const DB_HOST = '127.0.0.1';
const DB_NAME = 'lost_found_intelligence';
const DB_USER = 'root';
const DB_PASS = '';
const ALLOW_STAFF_SELF_REGISTER = true;      // false = self-registered accounts are always 'student'
const DEFAULT_NEW_USER_PASSWORD = 'ChangeMe123'; // for users added from the "Manage Users" screen

/* table => [primary key, columns the browser may write] */
const TABLES = [
    'item'          => ['item_id',          ['item_name', 'category_id', 'description', 'color', 'brand']],
    'lost_report'   => ['lost_report_id',   ['item_id', 'location_id', 'lost_date', 'description', 'status']],
    'found_report'  => ['found_report_id',  ['item_id', 'location_id', 'found_date', 'description', 'status', 'storage_id']],
    'match_record'  => ['match_id',         ['lost_report_id', 'found_report_id', 'match_score', 'match_reason', 'status']],
    'claim'         => ['claim_id',         ['match_id', 'claim_status', 'claim_description']],
    'evidence'      => ['evidence_id',      ['claim_id', 'evidence_type', 'evidence_description', 'is_private']],
    'investigation' => ['investigation_id', ['claim_id', 'investigator_id', 'investigation_date', 'investigation_status', 'findings', 'conclusion']],
    'witness_report'=> ['witness_report_id',['investigation_id', 'witness_name', 'witness_contact', 'witness_statement', 'report_date']],
    'cctv_ref'      => ['cctv_ref_id',      ['investigation_id', 'camera_id', 'footage_date', 'start_time', 'end_time', 'description']],
    'custody_event' => ['custody_event_id', ['found_report_id', 'storage_id', 'event_type', 'notes']],
    'handover'      => ['handover_id',      ['claim_id', 'handed_over_to', 'handover_status', 'notes']],
    'notification'  => ['notification_id',  ['user_id', 'notification_type', 'message', 'is_read']],
    'audit_log'     => ['audit_id',         ['action', 'table_name', 'record_id', 'action_description']],
    'user'          => ['user_id',          ['name', 'email', 'password', 'role', 'phone']],
];
const STAFF_ONLY_INSERT = ['investigation', 'witness_report', 'cctv_ref', 'custody_event', 'handover', 'user'];
const STAFF_ONLY_UPDATE = ['match_record', 'claim', 'investigation', 'handover'];

function fail(string $msg, int $code = 400): never
{
    http_response_code($code);
    echo json_encode(['error' => $msg]);
    exit;
}

try {
    $pdo = new PDO('mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4', DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,   // keeps integers as integers in the JSON
    ]);
    $pdo->exec("SET time_zone = '+00:00'");       // script.js reads TIMESTAMPs as UTC
} catch (PDOException $e) {
    fail('Database connection failed. Check DB_* settings in api.php.', 500);
}

function q(string $sql, array $params = []): array
{
    global $pdo;
    $st = $pdo->prepare($sql);
    $st->execute($params);
    return $st->columnCount() > 0 ? $st->fetchAll() : [];
}
function currentUser(): ?array
{
    if (empty($_SESSION['uid'])) return null;
    return q('SELECT user_id, name, email, role, phone FROM user WHERE user_id = ?', [$_SESSION['uid']])[0] ?? null;
}
function isStaff(?array $u): bool
{
    return $u !== null && in_array($u['role'], ['staff', 'admin'], true);
}
function passwordOk(string $plain, string $stored): bool
{
    // the sample data has plain-text passwords; new ones are hashed
    return password_get_info($stored)['algo'] !== null
        ? password_verify($plain, $stored)
        : hash_equals($stored, $plain);
}

$action = $_GET['action'] ?? '';
$in = json_decode(file_get_contents('php://input') ?: '[]', true) ?: [];

try {
    switch ($action) {

        case 'login': {
            $email = trim((string)($in['email'] ?? ''));
            $pass  = (string)($in['password'] ?? '');
            $row   = q('SELECT * FROM user WHERE email = ?', [$email])[0] ?? null;
            if (!$row || !passwordOk($pass, $row['password'])) fail('Incorrect email or password.', 401);
            if (password_get_info($row['password'])['algo'] === null) {   // upgrade plain-text password
                q('UPDATE user SET password = ? WHERE user_id = ?', [password_hash($pass, PASSWORD_DEFAULT), $row['user_id']]);
            }
            session_regenerate_id(true);
            $_SESSION['uid'] = (int)$row['user_id'];
            echo json_encode(['me' => currentUser()]);
            break;
        }

        case 'register': {
            $name  = trim((string)($in['name'] ?? ''));
            $email = trim((string)($in['email'] ?? ''));
            $pass  = (string)($in['password'] ?? '');
            $phone = trim((string)($in['contact'] ?? '')) ?: null;
            $role  = ($in['role'] ?? '') === 'staff' && ALLOW_STAFF_SELF_REGISTER ? 'staff' : 'student';
            if ($name === '' || $email === '' || $pass === '') fail('Name, email and password are required.');
            if (q('SELECT 1 FROM user WHERE email = ?', [$email])) fail('An account with that email already exists.');
            q('INSERT INTO user (name, email, password, role, phone) VALUES (?,?,?,?,?)',
              [mb_substr($name, 0, 100), mb_substr($email, 0, 150), password_hash($pass, PASSWORD_DEFAULT), $role, $phone ? mb_substr($phone, 0, 20) : null]);
            session_regenerate_id(true);
            $_SESSION['uid'] = (int)$pdo->lastInsertId();
            echo json_encode(['me' => currentUser()]);
            break;
        }

        case 'logout': {
            $_SESSION = [];
            session_destroy();
            echo json_encode(['ok' => true]);
            break;
        }

        case 'state': {
            $me = currentUser();
            if (!$me) { echo json_encode(['me' => null]); break; }
            $uid = (int)$me['user_id'];
            $staff = isStaff($me);
            $s = ['me' => $me];
            $s['category'] = q('SELECT * FROM category ORDER BY category_id');
            $s['location'] = q('SELECT * FROM location ORDER BY location_id');
            $s['storage']  = q('SELECT * FROM storage ORDER BY storage_id');
            $s['camera']   = q('SELECT * FROM camera ORDER BY camera_id');
            $s['item']     = q('SELECT * FROM item ORDER BY item_id');
            // Reports are readable by every logged-in user because the matching runs in the browser.
            $s['lost_report']  = q('SELECT * FROM lost_report ORDER BY lost_report_id');
            $s['found_report'] = q('SELECT * FROM found_report ORDER BY found_report_id');
            $s['notification'] = q('SELECT * FROM notification WHERE user_id = ? ORDER BY created_at DESC, notification_id DESC LIMIT 50', [$uid]);

            $hoJoin = 'SELECT h.*, c.match_id FROM handover h JOIN claim c ON c.claim_id = h.claim_id';
            if ($staff) {
                $s['user']           = q('SELECT user_id, name, email, role, phone FROM user ORDER BY user_id');
                $s['match_record']   = q('SELECT * FROM match_record ORDER BY match_id');
                $s['claim']          = q('SELECT * FROM claim ORDER BY claim_id');
                $s['evidence']       = q('SELECT * FROM evidence ORDER BY evidence_id');
                $s['investigation']  = q('SELECT * FROM investigation ORDER BY investigation_id');
                $s['witness_report'] = q('SELECT * FROM witness_report ORDER BY witness_report_id');
                $s['cctv_ref']       = q('SELECT * FROM cctv_ref ORDER BY cctv_ref_id');
                $s['custody_event']  = q('SELECT * FROM custody_event ORDER BY event_date, custody_event_id');
                $s['handover']       = q($hoJoin . ' ORDER BY h.handover_id');
                $s['audit_log']      = q('SELECT * FROM audit_log ORDER BY action_time DESC, audit_id DESC LIMIT 200');
            } else {
                $mine = 'JOIN lost_report l ON l.lost_report_id = m.lost_report_id JOIN found_report f ON f.found_report_id = m.found_report_id WHERE (l.user_id = ? OR f.user_id = ?)';
                $s['user']         = q('SELECT user_id, name, role FROM user ORDER BY user_id');   // names only
                $s['match_record'] = q('SELECT m.* FROM match_record m ' . $mine . ' ORDER BY m.match_id', [$uid, $uid]);
                $s['claim']        = q('SELECT * FROM claim WHERE user_id = ? ORDER BY claim_id', [$uid]);
                $s['evidence']     = q('SELECT e.* FROM evidence e JOIN claim c ON c.claim_id = e.claim_id WHERE c.user_id = ?', [$uid]);
                $s['handover']     = q($hoJoin . ' JOIN match_record m ON m.match_id = c.match_id ' . $mine . ' ORDER BY h.handover_id', [$uid, $uid]);
                foreach (['investigation', 'witness_report', 'cctv_ref', 'custody_event', 'audit_log'] as $k) $s[$k] = [];
            }
            echo json_encode($s);
            break;
        }

        case 'insert': {
            $me = currentUser() ?? fail('Please log in.', 401);
            $t = (string)($in['table'] ?? '');
            if (!isset(TABLES[$t])) fail('Unknown table.');
            $staff = isStaff($me);
            if (in_array($t, STAFF_ONLY_INSERT, true) && !$staff) fail('Staff only.', 403);
            [, $cols] = TABLES[$t];
            $d = array_intersect_key((array)($in['data'] ?? []), array_flip($cols));

            // values the browser must not choose
            if (!$staff) foreach (['status', 'claim_status'] as $k) unset($d[$k]);
            $forceUser = ['lost_report' => 'user_id', 'found_report' => 'user_id', 'claim' => 'user_id',
                          'audit_log' => 'user_id', 'custody_event' => 'user_id', 'handover' => 'handed_over_by'];
            if (isset($forceUser[$t])) $d[$forceUser[$t]] = (int)$me['user_id'];

            if ($t === 'user') {
                $d['password'] = password_hash((string)($d['password'] ?? DEFAULT_NEW_USER_PASSWORD), PASSWORD_DEFAULT);
                if (!in_array($d['role'] ?? '', ['student', 'staff', 'admin'], true)) $d['role'] = 'student';
            }
            if ($t === 'match_record') {                       // never create the same pair twice
                $ex = q('SELECT match_id FROM match_record WHERE lost_report_id = ? AND found_report_id = ?',
                        [$d['lost_report_id'] ?? 0, $d['found_report_id'] ?? 0])[0] ?? null;
                if ($ex) { echo json_encode(['id' => (int)$ex['match_id'], 'existed' => true]); break; }
            }
            if (!$d) fail('No data.');
            $names = implode(',', array_map(fn($c) => "`$c`", array_keys($d)));
            $marks = implode(',', array_fill(0, count($d), '?'));
            q("INSERT INTO `$t` ($names) VALUES ($marks)", array_values($d));
            echo json_encode(['id' => (int)$pdo->lastInsertId()]);
            break;
        }

        case 'update': {
            $me = currentUser() ?? fail('Please log in.', 401);
            $t = (string)($in['table'] ?? '');
            $id = (int)($in['id'] ?? 0);
            if (!isset(TABLES[$t])) fail('Unknown table.');
            $staff = isStaff($me);
            $uid = (int)$me['user_id'];
            [$pk, $cols] = TABLES[$t];
            $d = array_intersect_key((array)($in['data'] ?? []), array_flip($cols));
            $where = "`$pk` = ?";

            if ($t === 'notification') {                       // own notifications, is_read only
                $d = array_intersect_key($d, ['is_read' => 1]);
                $where .= ' AND user_id = ?';
                $extra = [$uid];
            } elseif ($t === 'user') {                         // own profile only; role can't be changed here
                if ($id !== $uid) fail('You can only edit your own profile.', 403);
                $d = array_intersect_key($d, array_flip(['name', 'email', 'phone', 'password']));
                if (isset($d['password'])) {
                    if ($d['password'] === '') unset($d['password']);
                    else $d['password'] = password_hash((string)$d['password'], PASSWORD_DEFAULT);
                }
                $extra = [];
            } elseif ($t === 'lost_report' || $t === 'found_report') {
                $owner = q("SELECT user_id FROM `$t` WHERE `$pk` = ?", [$id])[0]['user_id'] ?? null;
                $onlyMatched = array_keys($d) === ['status'] && $d['status'] === 'matched';   // set by the matching engine
                if (!$staff && (int)$owner !== $uid && !$onlyMatched) fail('Not allowed.', 403);
                $extra = [];
            } elseif (in_array($t, STAFF_ONLY_UPDATE, true)) {
                if (!$staff) fail('Staff only.', 403);
                $extra = [];
            } else {
                fail('This table cannot be updated.', 403);
            }
            if (!$d) fail('Nothing to update.');
            $set = implode(',', array_map(fn($c) => "`$c` = ?", array_keys($d)));
            q("UPDATE `$t` SET $set WHERE $where", array_merge(array_values($d), [$id], $extra));
            echo json_encode(['ok' => true]);
            break;
        }

        default:
            fail('Unknown action.', 404);
    }
} catch (PDOException $e) {
    $msg = $e->getCode() === '23000' && str_contains($e->getMessage(), 'email')
        ? 'That email is already registered.'
        : 'Database error: ' . $e->getMessage();
    fail($msg, 500);
}
