/* =====================================================================
   DATA LAYER — talks to api.php, which reads/writes the MySQL database
   `lost_found_intelligence`.

   The UI code below keeps working on the same in-memory `DB` object it
   always used. buildDB() translates the real tables (user, lost_report,
   found_report, item, match_record, claim, ...) into that shape, and every
   change is written back to the tables through dbInsert()/dbUpdate().
   ===================================================================== */
const API_URL = "api.php";
const DEMO_PASSWORD = "password123"; // password of the seeded demo accounts

let DB = emptyDB(); // UI-shaped data (built from RAW)
let RAW = null; // last snapshot of table rows from the server
let ui = {
  route: "dashboard",
  currentUserId: null,
  notifOpen: false,
  authMode: "login",
  toast: null,
  routeParam: null,
};

function emptyDB() {
  return {
    categories: [],
    users: [],
    locations: [],
    storages: [],
    cameras: [],
    lostReports: [],
    foundReports: [],
    matches: [],
    claims: [],
    evidence: [],
    investigations: [],
    witnessReports: [],
    cctvRefs: [],
    custodyEvents: [],
    handovers: [],
    auditLog: [],
    notifications: [],
  };
}

/* ---------------- small utilities ---------------- */
const S = (v) => (v === null || v === undefined ? null : String(v)); // id -> string
const N = (v) => (v === null || v === undefined || v === "" ? null : Number(v)); // id -> number
const clip = (s, n) => String(s || "").slice(0, n); // respect varchar limits
const cap = (s) => (s ? s.charAt(0).toUpperCase() + s.slice(1) : s);
const tsISO = (t) => (t ? String(t).replace(" ", "T") + "Z" : null); // DB timestamps are UTC
const todayStr = () => new Date().toLocaleDateString("en-CA"); // YYYY-MM-DD
function esc(s) {
  return String(s ?? "").replace(
    /[&<>"']/g,
    (c) =>
      ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[
        c
      ],
  );
}
function nowISO() {
  return new Date().toISOString();
}
function fmtDate(iso) {
  if (!iso) return "—";
  const dateOnly = /^\d{4}-\d{2}-\d{2}$/.test(iso); // DATE columns have no time
  const d = new Date(dateOnly ? iso + "T00:00:00" : iso);
  const day = d.toLocaleDateString(undefined, { month: "short", day: "numeric" });
  if (dateOnly) return day;
  return (
    day +
    ", " +
    d.toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit" })
  );
}
function guard(fn) {
  return async (...args) => {
    try {
      await fn(...args);
    } catch (e) {
      console.error(e);
      toast(e.message || "Something went wrong.");
    }
  };
}

/* ---------------- API client ---------------- */
async function api(action, body) {
  let res;
  try {
    res = await fetch(`${API_URL}?action=${action}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "same-origin",
      body: JSON.stringify(body || {}),
    });
  } catch (e) {
    throw new Error(
      "Cannot reach the server. Is Apache running and the app opened through http://localhost/ ?",
    );
  }
  let data;
  try {
    data = await res.json();
  } catch (e) {
    throw new Error("Server sent an invalid response — check api.php / PHP errors.");
  }
  if (res.status === 401 && action !== "login") {
    ui.currentUserId = null;
    DB = emptyDB();
    RAW = null;
    render();
  }
  if (!res.ok || data.error) throw new Error(data.error || "Request failed.");
  return data;
}
async function dbInsert(table, data) {
  return (await api("insert", { table, data })).id;
}
async function dbUpdate(table, id, data) {
  await api("update", { table, id: N(id), data });
}
async function loadState() {
  RAW = await api("state");
  if (!RAW.me) {
    ui.currentUserId = null;
    DB = emptyDB();
    return;
  }
  ui.currentUserId = S(RAW.me.user_id);
  DB = buildDB(RAW);
}
async function persist() {
  try {
    await loadState();
  } catch (e) {
    console.error(e);
  }
  render();
}

/* ---------------- tables -> UI shape ----------------
   Status words the UI shows (Open, Matched, Claimed, Resolved, Suggested,
   Approved...) are derived from the enum columns plus related rows, because
   the enums in your tables are narrower than what the screens display. */
function buildDB(raw) {
  const rows = (k) => raw[k] || [];
  const db = emptyDB();
  const catById = new Map(rows("category").map((c) => [c.category_id, c]));
  const itemById = new Map(rows("item").map((i) => [i.item_id, i]));
  const rawLoc = (l) => `${l.location_name} — ${l.address || l.city || ""}`;

  db.categories = rows("category").map((c) => esc(c.category_name));
  db.users = rows("user").map((u) => ({
    id: S(u.user_id),
    name: esc(u.name),
    email: esc(u.email || ""),
    role: u.role,
    contact: esc(u.phone || ""),
  }));
  const meRow = db.users.find((u) => u.id === S(raw.me.user_id));
  if (meRow) {
    meRow.email = esc(raw.me.email || "");
    meRow.contact = esc(raw.me.phone || "");
  }
  db.locations = rows("location").map((l) => ({
    id: S(l.location_id),
    building: esc(l.location_name),
    room: esc(l.address || l.city || ""),
  }));
  db.storages = rows("storage").map((s) => ({
    id: S(s.storage_id),
    name: esc(s.storage_name),
  }));
  db.cameras = rows("camera").map((c) => ({
    id: S(c.camera_id),
    label: esc(c.camera_name),
  }));

  /* reports (+ their item row) */
  const mapReport = (r, idCol, dateCol) => {
    const it = itemById.get(r.item_id) || {};
    const cat = catById.get(it.category_id);
    return {
      id: S(r[idCol]),
      userId: S(r.user_id),
      itemId: S(r.item_id),
      category: esc(cat ? cat.category_name : "Uncategorised"),
      brand: esc(it.brand || ""),
      color: esc(it.color || ""),
      description: esc(r.description || it.description || ""),
      itemDescription: esc(it.description || ""),
      locationId: S(r.location_id),
      datetime: r[dateCol], // DATE column -> "YYYY-MM-DD"
      dbStatus: r.status,
      status: "",
      createdAt: tsISO(r.created_at),
    };
  };
  db.lostReports = rows("lost_report").map((r) =>
    mapReport(r, "lost_report_id", "lost_date"),
  );
  db.foundReports = rows("found_report").map((r) =>
    Object.assign(mapReport(r, "found_report_id", "found_date"), {
      storageId: S(r.storage_id),
    }),
  );

  /* claims, evidence */
  const claimsRaw = rows("claim");
  const claimsByMatch = {};
  claimsRaw.forEach((c) =>
    (claimsByMatch[c.match_id] = claimsByMatch[c.match_id] || []).push(c),
  );
  const evByClaim = {};
  rows("evidence").forEach((e) =>
    (evByClaim[e.claim_id] = evByClaim[e.claim_id] || []).push(e),
  );
  const decision = {}; // latest approve/reject audit row per claim (audit is newest-first)
  rows("audit_log").forEach((a) => {
    if (
      a.table_name === "claim" &&
      (a.action === "Approved Claim" || a.action === "Rejected Claim") &&
      !decision[a.record_id]
    )
      decision[a.record_id] = a;
  });
  db.claims = claimsRaw.map((c) => {
    const d = decision[c.claim_id];
    return {
      id: S(c.claim_id),
      matchId: S(c.match_id),
      claimantId: S(c.user_id),
      privateEvidence: esc(c.claim_description || ""),
      evidenceNote: esc(
        (evByClaim[c.claim_id] || [])
          .map((e) => e.evidence_description)
          .filter(Boolean)
          .join("; "),
      ),
      status: cap(c.claim_status),
      createdAt: tsISO(c.claim_date),
      reviewedBy: d ? S(d.user_id) : null,
      reason: d ? esc(d.action_description || "") : "",
    };
  });
  db.evidence = rows("evidence").map((e) => ({
    id: S(e.evidence_id),
    claimId: S(e.claim_id),
    type: esc(e.evidence_type || ""),
    reference: esc(e.evidence_description || ""),
    verifiedBy: null,
  }));

  /* matches */
  const doneMatch = new Set(
    rows("handover")
      .filter((h) => h.handover_status === "completed")
      .map((h) => String(h.match_id)),
  );
  db.matches = rows("match_record").map((m) => {
    const cl = claimsByMatch[m.match_id] || [];
    let status = "Suggested";
    if (m.status === "rejected") status = "Rejected";
    else if (
      doneMatch.has(String(m.match_id)) ||
      cl.some((c) => c.claim_status === "approved")
    )
      status = "Approved";
    else if (cl.some((c) => c.claim_status === "pending")) status = "Claimed";
    else if (m.status === "confirmed") status = "Confirmed";
    return {
      id: S(m.match_id),
      lostReportId: S(m.lost_report_id),
      foundReportId: S(m.found_report_id),
      score: Number(m.match_score),
      reason: esc(m.match_reason || ""),
      status,
      dbStatus: m.status,
      createdAt: tsISO(m.created_at),
    };
  });
  const byLost = {},
    byFound = {};
  db.matches.forEach((m) => {
    (byLost[m.lostReportId] = byLost[m.lostReportId] || []).push(m);
    (byFound[m.foundReportId] = byFound[m.foundReportId] || []).push(m);
  });
  db.lostReports.forEach((r) => {
    const ms = byLost[r.id] || [];
    if (ms.some((m) => doneMatch.has(m.id))) r.status = "Resolved";
    else if (r.dbStatus === "closed") r.status = "Closed";
    else if (ms.some((m) => m.status === "Claimed" || m.status === "Approved"))
      r.status = "Claimed";
    else if (r.dbStatus === "matched") r.status = "Matched";
    else r.status = "Open";
  });
  db.foundReports.forEach((r) => {
    const ms = byFound[r.id] || [];
    if (ms.some((m) => doneMatch.has(m.id))) r.status = "Resolved";
    else if (r.dbStatus === "closed") r.status = "Closed";
    else if (r.dbStatus === "claimed") r.status = "Claimed";
    else if (r.dbStatus === "matched") r.status = "Matched";
    else r.status = "Open";
  });

  /* investigations, witnesses, CCTV */
  const claimRawById = {},
    matchRawById = {};
  claimsRaw.forEach((c) => (claimRawById[c.claim_id] = c));
  rows("match_record").forEach((m) => (matchRawById[m.match_id] = m));
  const invStatus = {
    open: "Open",
    in_progress: "Open",
    completed: "Closed",
    closed: "Closed",
  };
  db.investigations = rows("investigation").map((i) => {
    const c = claimRawById[i.claim_id];
    const m = c && matchRawById[c.match_id];
    return {
      id: S(i.investigation_id),
      claimId: S(i.claim_id),
      lostReportId: m ? S(m.lost_report_id) : null,
      openedBy: S(i.investigator_id),
      reason: esc(i.findings || i.conclusion || ""),
      conclusion: esc(i.conclusion || ""),
      status: invStatus[i.investigation_status] || "Open",
      createdAt: tsISO(i.created_at),
    };
  });
  // witness_report has no location column, so the location is kept as a
  // readable "[at: <place>]" suffix on the statement and split back out here.
  const locByLabel = {};
  rows("location").forEach((l) => (locByLabel[rawLoc(l)] = S(l.location_id)));
  db.witnessReports = rows("witness_report").map((w) => {
    const m = /^([\s\S]*?)\s*\[at: (.+)\]$/.exec(w.witness_statement || "");
    return {
      id: S(w.witness_report_id),
      investigationId: S(w.investigation_id),
      statement: esc(m ? m[1] : w.witness_statement),
      locationId: m ? locByLabel[m[2]] || null : null,
      witnessName: esc(w.witness_name),
      contact: esc(w.witness_contact || ""),
    };
  });
  const hhmm = (t) => String(t).slice(0, 5);
  db.cctvRefs = rows("cctv_ref").map((c) => ({
    id: S(c.cctv_ref_id),
    investigationId: S(c.investigation_id),
    cameraId: S(c.camera_id),
    footageDate: c.footage_date,
    timeWindow:
      c.start_time && c.end_time
        ? `${hhmm(c.start_time)}–${hhmm(c.end_time)}`
        : esc(c.description || ""),
  }));

  /* custody + handover */
  const lastStorage = {};
  db.custodyEvents = rows("custody_event").map((e) => {
    const fr = db.foundReports.find((f) => f.id === S(e.found_report_id));
    const sid = S(e.storage_id);
    const from = lastStorage[e.found_report_id] || null;
    const released = e.event_type === "released";
    lastStorage[e.found_report_id] = released ? null : sid || from;
    return {
      id: S(e.custody_event_id),
      itemRef: fr
        ? `${fr.category}${fr.brand ? " — " + fr.brand : ""} (found report #${fr.id})`
        : `Found report #${e.found_report_id}`,
      fromStorage: released ? sid || from : from,
      toStorage: released ? null : sid,
      staffId: S(e.user_id),
      timestamp: tsISO(e.event_date),
      type: e.event_type,
    };
  });
  db.handovers = rows("handover").map((h) => ({
    id: S(h.handover_id),
    claimId: S(h.claim_id),
    matchId: S(h.match_id),
    staffId: S(h.handed_over_by),
    recipientId: S(h.handed_over_to),
    datetime: tsISO(h.handover_date),
    status: h.handover_status,
  }));

  /* notifications + audit log */
  db.notifications = rows("notification").map((n) => ({
    id: S(n.notification_id),
    userId: S(n.user_id),
    type: n.notification_type,
    text: esc(n.message),
    read: Number(n.is_read) === 1,
    createdAt: tsISO(n.created_at),
  }));
  db.auditLog = rows("audit_log").map((a) => ({
    id: S(a.audit_id),
    userId: S(a.user_id),
    action: esc(a.action),
    entityRef: a.table_name ? esc(`${a.table_name} #${a.record_id}`) : "",
    description: esc(a.action_description || ""),
    timestamp: tsISO(a.action_time),
  }));
  return db;
}

/* ---------------- HELPERS ---------------- */
function currentUser() {
  return DB.users.find((u) => u.id === ui.currentUserId);
}
function isStaffRole(u) {
  return !!u && (u.role === "staff" || u.role === "admin");
}
function isStaff() {
  return isStaffRole(currentUser());
}
function locName(id) {
  const l = DB.locations.find((x) => x.id === id);
  return l ? `${l.building} — ${l.room}` : "—";
}
function storageName(id) {
  const s = DB.storages.find((x) => x.id === id);
  return s ? s.name : "—";
}
function userName(id) {
  const u = DB.users.find((x) => x.id === id);
  return u ? u.name : id === "system" ? "System" : "Unknown";
}
function plainUserName(id) {
  // un-escaped name, for text that is stored back into the database
  const u = ((RAW && RAW.user) || []).find((x) => S(x.user_id) === id);
  return u ? u.name : "A user";
}
function badge(status) {
  const cls = "badge-" + status.toLowerCase();
  return `<span class="badge ${cls}">${status}</span>`;
}
async function addAudit(action, table, recordId, description) {
  try {
    await api("insert", {
      table: "audit_log", // user_id is taken from the login session by api.php
      data: {
        action: clip(action, 100),
        table_name: table || null,
        record_id: N(recordId),
        action_description: description ? clip(description, 255) : null,
      },
    });
  } catch (e) {
    console.error("Audit log write failed", e);
  }
}
async function notify(userId, text, type) {
  try {
    await dbInsert("notification", {
      user_id: N(userId),
      notification_type: type || null,
      message: clip(text, 255),
    });
  } catch (e) {
    console.error("Notification write failed", e);
  }
}
function myNotifs() {
  return DB.notifications
    .filter((n) => n.userId === ui.currentUserId)
    .slice(0, 25);
}
function unreadCount() {
  return myNotifs().filter((n) => !n.read).length;
}

/* claim / investigation lookups (investigation.claim_id is required) */
function claimForLostReport(lostReportId) {
  const mids = DB.matches
    .filter((m) => m.lostReportId === lostReportId)
    .map((m) => m.id);
  const cl = DB.claims.filter((c) => mids.includes(c.matchId));
  return cl.sort((a, b) => Number(b.id) - Number(a.id))[0] || null;
}
function investigableLostReports() {
  return DB.lostReports.filter((r) => claimForLostReport(r.id));
}
function rawLocLabel(id) {
  const l = ((RAW && RAW.location) || []).find((x) => S(x.location_id) === id);
  return l ? `${l.location_name} — ${l.address || l.city || ""}` : "";
}
// "2:00–2:30 PM" / "14:00-14:30" -> { start: "14:00:00", end: "14:30:00" }
function parseTimeWindow(text) {
  const m =
    /(\d{1,2})(?::(\d{2}))?\s*(am|pm)?\s*(?:-|–|—|to)\s*(\d{1,2})(?::(\d{2}))?\s*(am|pm)?/i.exec(
      text || "",
    );
  if (!m) return { start: null, end: null };
  const ap = m[6] || m[3];
  const to24 = (h, min, meridiem) => {
    h = Number(h);
    if (meridiem) {
      const p = meridiem.toLowerCase();
      if (p === "pm" && h < 12) h += 12;
      if (p === "am" && h === 12) h = 0;
    }
    return h > 23 || Number(min || 0) > 59
      ? null
      : `${String(h).padStart(2, "0")}:${min || "00"}:00`;
  };
  const start = to24(m[1], m[2], m[3] || ap);
  const end = to24(m[4], m[5], m[6] || ap);
  return start && end ? { start, end } : { start: null, end: null };
}

/* ---------------- MATCHING ENGINE ---------------- */
function jaccardWords(a, b) {
  const wa = new Set((a || "").toLowerCase().match(/[a-z0-9]+/g) || []);
  const wb = new Set((b || "").toLowerCase().match(/[a-z0-9]+/g) || []);
  if (wa.size === 0 || wb.size === 0) return 0;
  let inter = 0;
  wa.forEach((w) => {
    if (wb.has(w)) inter++;
  });
  const union = new Set([...wa, ...wb]).size;
  return inter / union;
}
function scoreMatch(lost, found) {
  let score = 0;
  if (lost.category === found.category) score += 30;
  if (
    lost.color &&
    found.color &&
    lost.color.toLowerCase() === found.color.toLowerCase()
  )
    score += 15;
  const kw = jaccardWords(
    [lost.description, lost.itemDescription, lost.brand].join(" "),
    [found.description, found.itemDescription, found.brand].join(" "),
  );
  score += Math.round(kw * 30);
  if (lost.locationId === found.locationId) score += 15;
  const dt1 = new Date(lost.datetime).getTime(),
    dt2 = new Date(found.datetime).getTime();
  const hoursDiff = Math.abs(dt1 - dt2) / 36e5;
  if (hoursDiff <= 48) score += 10;
  else if (hoursDiff <= 168) score += 5;
  return Math.min(100, score);
}
function matchReason(lost, found) {
  const r = [];
  if (lost.category === found.category) r.push("same category");
  if (
    lost.color &&
    found.color &&
    lost.color.toLowerCase() === found.color.toLowerCase()
  )
    r.push("same color");
  if (jaccardWords(lost.brand, found.brand) > 0) r.push("similar brand/model");
  if (jaccardWords(lost.description, found.description) > 0.15)
    r.push("similar description");
  if (lost.locationId === found.locationId) r.push("same location");
  const hrs =
    Math.abs(new Date(lost.datetime) - new Date(found.datetime)) / 36e5;
  if (hrs <= 48) r.push("reported within 48 hours");
  return clip(cap(r.join(", ")) || "Partial similarity", 255);
}
// Compares one newly filed report against every open report of the opposite kind.
async function recomputeMatches(rec, kind) {
  const pool = kind === "lost" ? DB.foundReports : DB.lostReports;
  const closed = (r) => r.status === "Closed" || r.status === "Resolved";
  for (const other of pool) {
    const lost = kind === "lost" ? rec : other;
    const found = kind === "lost" ? other : rec;
    if (closed(lost) || closed(found)) continue;
    const s = scoreMatch(lost, found);
    if (s < 45) continue;
    const r = await api("insert", {
      table: "match_record",
      data: {
        lost_report_id: N(lost.id),
        found_report_id: N(found.id),
        match_score: s,
        match_reason: matchReason(lost, found),
        status: "pending",
      },
    });
    if (r.existed) continue; // pair was already matched
    await addAudit(`Auto-match generated (score ${s})`, "match_record", r.id);
    if (lost.status === "Open") {
      await dbUpdate("lost_report", lost.id, { status: "matched" });
      lost.status = "Matched";
    }
    if (found.status === "Open") {
      await dbUpdate("found_report", found.id, { status: "matched" });
      found.status = "Matched";
    }
    await notify(
      lost.userId,
      `A potential match (${s}% confidence) was found for your lost report.`,
      "Match Found",
    );
    await notify(
      found.userId,
      `A potential match (${s}% confidence) was found for your found report.`,
      "Match Found",
    );
  }
}

/* ---------------- ROUTER / RENDER ---------------- */
function go(route, param) {
  ui.route = route;
  ui.routeParam = param || null;
  ui.notifOpen = false;
  render();
}
function toast(msg) {
  const safe = esc(msg);
  ui.toast = safe;
  render();
  setTimeout(() => {
    if (ui.toast === safe) {
      ui.toast = null;
      render();
    }
  }, 2800);
}

function init() {
  return (async () => {
    let err = null;
    try {
      await loadState(); // restores the session if the user is still logged in
    } catch (e) {
      err = e;
    }
    render();
    if (err) toast(err.message);
  })();
}

function render() {
  const app = document.getElementById("app");
  if (!ui.currentUserId || !currentUser()) {
    app.innerHTML =
      renderLogin() +
      (ui.toast
        ? `<div class="toast-wrap"><div class="toast">${ui.toast}</div></div>`
        : "");
    bindLogin();
    return;
  }
  app.innerHTML = renderShell();
  bindShell();
}

/* ---------------- LOGIN VIEW ---------------- */
function renderLogin() {
  const mode = ui.authMode;
  return `
  <div class="login-wrap">
    <div class="login-card">
      <div class="brand">
        <div class="headline" style="font-size:20px;">Ctrl<span>+</span>HER</div>
        <small style="color:var(--text-dim);">Lost &amp; Found Intelligence System</small>
      </div>
      <div class="seg">
        <div id="tab-login" class="${mode === "login" ? "active" : ""}">Log in</div>
        <div id="tab-register" class="${mode === "register" ? "active" : ""}">Register</div>
      </div>
      ${
        mode === "login"
          ? `
        <div class="field"><label>Email</label><input id="li-email" placeholder="you@ctrlher.edu"></div>
        <div class="field"><label>Password</label><input id="li-pass" type="password" placeholder="••••••••"></div>
        <button class="btn btn-primary" style="width:100%" id="do-login">Log in</button>
        <div class="hint">Log in with your registered email and password, or use a demo account below.</div>
        <div class="demo-users">
          <button class="btn btn-sm" data-demo="ayesha@example.com">Ayesha (student)</button>
          <button class="btn btn-sm" data-demo="nabil@example.com">Nabil (student)</button>
          <button class="btn btn-sm" data-demo="sara@example.com">Sara (staff)</button>
        </div>
      `
          : `
        <div class="field"><label>Full name</label><input id="rg-name" placeholder="Jane Doe"></div>
        <div class="field"><label>Email</label><input id="rg-email" placeholder="you@ctrlher.edu"></div>
        <div class="field"><label>Contact number</label><input id="rg-contact" placeholder="01700-000000"></div>
        <div class="field">
          <label>Role</label>
          <select id="rg-role"><option value="student">Student</option><option value="staff">Staff / Admin</option></select>
        </div>
        <div class="field"><label>Password</label><input id="rg-pass" type="password" placeholder="••••••••"></div>
        <button class="btn btn-primary" style="width:100%" id="do-register">Create account</button>
      `
      }
    </div>
  </div>`;
}
function bindLogin() {
  const t1 = document.getElementById("tab-login"),
    t2 = document.getElementById("tab-register");
  if (t1)
    t1.onclick = () => {
      ui.authMode = "login";
      render();
    };
  if (t2)
    t2.onclick = () => {
      ui.authMode = "register";
      render();
    };
  const signIn = async (action, payload) => {
    const r = await api(action, payload);
    await addAudit(
      action === "register" ? "Registered new account" : "Logged in",
      "user",
      r.me.user_id,
    );
    await loadState();
    render();
  };
  document.querySelectorAll("[data-demo]").forEach((b) => {
    b.onclick = guard(() =>
      signIn("login", { email: b.dataset.demo, password: DEMO_PASSWORD }),
    );
  });
  const doLogin = document.getElementById("do-login");
  if (doLogin)
    doLogin.onclick = async () => {
      const email = document.getElementById("li-email").value.trim();
      const password = document.getElementById("li-pass").value;
      const fail = (msg) => {
        toast(msg);
        const el = document.getElementById("li-email");
        if (el) el.value = email; // keep what was typed
      };
      if (!email || !password) return fail("Enter your email and password.");
      try {
        await signIn("login", { email, password });
      } catch (e) {
        fail(e.message);
      }
    };
  const doReg = document.getElementById("do-register");
  if (doReg)
    doReg.onclick = async () => {
      const name = document.getElementById("rg-name").value.trim();
      const email = document.getElementById("rg-email").value.trim();
      const contact = document.getElementById("rg-contact").value.trim();
      const role = document.getElementById("rg-role").value;
      const password = document.getElementById("rg-pass").value;
      if (!name || !email || !password) {
        toast("Name, email and password are required.");
        return;
      }
      try {
        await signIn("register", { name, email, contact, role, password });
      } catch (e) {
        toast(e.message);
      }
    };
}

/* ---------------- SHELL (sidebar + topbar) ---------------- */
function renderShell() {
  const u = currentUser();
  const staff = isStaff();
  const navItems = [
    { r: "dashboard", ico: "⌂", label: "Dashboard" },
    { r: "report-lost", ico: "✎", label: "Report Lost Item" },
    { r: "report-found", ico: "✎", label: "Report Found Item" },
    { r: "my-items", ico: "▤", label: "My Items" },
    { r: "matches", ico: "⇄", label: "Potential Matches" },
    { r: "notifications", ico: "◔", label: "Notifications" },
  ];
  const staffItems = [
    { r: "staff-review", ico: "☑", label: "Review Claims" },
    { r: "investigations", ico: "⌕", label: "Investigations" },
    { r: "custody", ico: "⌂", label: "Storage & Custody" },
    { r: "analytics", ico: "▥", label: "Analytics" },
    { r: "audit", ico: "≡", label: "Audit Log" },
    { r: "users", ico: "◎", label: "Manage Users" },
  ];

  return `
  <div class="sidebar">
    <div class="brand">Ctrl<span>+</span>HER<small>Lost &amp; Found Intelligence</small></div>
    ${navItems.map((n) => `<div class="nav-item ${ui.route === n.r ? "active" : ""}" data-route="${n.r}"><span class="ico">${n.ico}</span>${n.label}</div>`).join("")}
    ${staff ? `<div class="nav-section-label">Staff &amp; Admin</div>${staffItems.map((n) => `<div class="nav-item ${ui.route === n.r ? "active" : ""}" data-route="${n.r}"><span class="ico">${n.ico}</span>${n.label}</div>`).join("")}` : ""}
    <div class="sidebar-footer">
      <div class="nav-item" data-route="profile"><span class="ico">☺</span>My Profile</div>
      <div class="nav-item" id="logout-btn"><span class="ico">⏻</span>Log out</div>
    </div>
  </div>
  <div class="main">
    <div class="topbar">
      <div>
        <h1>${routeTitle(ui.route)}</h1>
        <div class="sub">${routeSub(ui.route)}</div>
      </div>
      <div class="topbar-right">
        <div class="bell" id="bell-btn">🔔${unreadCount() > 0 ? '<div class="dot"></div>' : ""}</div>
        <div class="user-chip">
          <div class="avatar">${u.name
            .split(" ")
            .map((s) => s[0])
            .slice(0, 2)
            .join("")}</div>
          <div>
            <div style="font-size:12.5px;font-weight:600;">${u.name}</div>
            <div style="font-size:10.5px;color:var(--text-dim);text-transform:capitalize;">${u.role}</div>
          </div>
        </div>
      </div>
    </div>
    <div class="content">${renderRoute()}</div>
  </div>
  ${ui.notifOpen ? renderNotifPanel() : ""}
  ${ui.toast ? `<div class="toast-wrap"><div class="toast">${ui.toast}</div></div>` : ""}
  `;
}
function routeTitle(r) {
  const map = {
    dashboard: "Dashboard",
    "report-lost": "Report a Lost Item",
    "report-found": "Report a Found Item",
    "my-items": "My Items",
    matches: "Potential Matches",
    notifications: "Notifications",
    "staff-review": "Review Claims",
    investigations: "Investigation Support",
    custody: "Storage & Custody",
    analytics: "Reports & Analytics",
    audit: "Audit Log",
    users: "Manage Users",
    profile: "My Profile",
  };
  return map[r] || "Dashboard";
}
function routeSub(r) {
  const map = {
    dashboard: "Overview of campus lost & found activity",
    "report-lost":
      "Fill in as much detail as possible — it improves match accuracy",
    "report-found": "Log an item you've found so it can be matched to a claim",
    "my-items": "Every lost or found report you've submitted",
    matches: "Ranked matches from the intelligent matching engine",
    notifications: "Match alerts and claim status updates",
    "staff-review": "Compare claim evidence against found items",
    investigations: "Attach witness statements and CCTV references to a case",
    custody: "Track where physical items are stored and who holds them",
    analytics: "Recovery rate and system-wide reporting",
    audit: "Full trace of actions taken across the system",
    users: "All registered students and staff",
    profile: "Account details",
  };
  return map[r] || "";
}
function renderNotifPanel() {
  const list = myNotifs();
  return `<div class="notif-panel">
    ${list.length ? list.map((n) => `<div class="notif-item"><div>${n.text}</div><div class="t">${fmtDate(n.createdAt)}</div></div>`).join("") : `<div class="empty-state" style="padding:20px;"><div>No notifications yet</div></div>`}
  </div>`;
}
function bindShell() {
  document.querySelectorAll("[data-route]").forEach((el) => {
    el.onclick = () => go(el.dataset.route);
  });
  document.getElementById("logout-btn").onclick = guard(async () => {
    await addAudit("Logged out", "user", ui.currentUserId);
    await api("logout");
    ui.currentUserId = null;
    ui.route = "dashboard";
    DB = emptyDB();
    RAW = null;
    render();
  });
  const bell = document.getElementById("bell-btn");
  bell.onclick = (e) => {
    e.stopPropagation();
    ui.notifOpen = !ui.notifOpen;
    if (ui.notifOpen) {
      const unread = myNotifs().filter((n) => !n.read);
      unread.forEach((n) => (n.read = true));
      Promise.all(
        unread.map((n) => dbUpdate("notification", n.id, { is_read: 1 })),
      ).catch(console.error);
    }
    render();
  };
  bindRouteEvents();
}

/* ---------------- ROUTE CONTENT ---------------- */
function renderRoute() {
  switch (ui.route) {
    case "dashboard":
      return renderDashboard();
    case "report-lost":
      return renderReportForm("lost");
    case "report-found":
      return renderReportForm("found");
    case "my-items":
      return renderMyItems();
    case "matches":
      return renderMatches();
    case "notifications":
      return renderNotificationsPage();
    case "staff-review":
      return isStaff() ? renderStaffReview() : accessDenied();
    case "investigations":
      return isStaff() ? renderInvestigations() : accessDenied();
    case "custody":
      return isStaff() ? renderCustody() : accessDenied();
    case "analytics":
      return isStaff() ? renderAnalytics() : accessDenied();
    case "audit":
      return isStaff() ? renderAuditLog() : accessDenied();
    case "users":
      return isStaff() ? renderUsers() : accessDenied();
    case "profile":
      return renderProfile();
    default:
      return renderDashboard();
  }
}
function accessDenied() {
  return `<div class="empty-state"><div class="ico">🔒</div>Staff/Admin access only.</div>`;
}

function bindRouteEvents() {
  switch (ui.route) {
    case "dashboard":
      bindDashboard();
      break;
    case "report-lost":
      bindReportForm("lost");
      break;
    case "report-found":
      bindReportForm("found");
      break;
    case "my-items":
      bindMyItems();
      break;
    case "matches":
      bindMatches();
      break;
    case "staff-review":
      if (isStaff()) bindStaffReview();
      break;
    case "investigations":
      if (isStaff()) bindInvestigations();
      break;
    case "custody":
      if (isStaff()) bindCustody();
      break;
    case "users":
      if (isStaff()) bindUsers();
      break;
    case "profile":
      bindProfile();
      break;
  }
}

/* ---------------- DASHBOARD ---------------- */
function renderDashboard() {
  const u = currentUser();
  const myLost = DB.lostReports.filter((r) => r.userId === u.id);
  const myFound = DB.foundReports.filter((r) => r.userId === u.id);
  const myMatches = DB.matches.filter((m) => {
    const lr = DB.lostReports.find((x) => x.id === m.lostReportId);
    const fr = DB.foundReports.find((x) => x.id === m.foundReportId);
    return (lr && lr.userId === u.id) || (fr && fr.userId === u.id);
  });
  const resolved = [...myLost, ...myFound].filter(
    (r) => r.status === "Resolved" || r.status === "Closed",
  ).length;

  return `
  <div class="grid grid-4">
    <div class="card stat-card"><div class="num">${myLost.length}</div><div class="label">Lost reports filed</div></div>
    <div class="card stat-card"><div class="num">${myFound.length}</div><div class="label">Found reports filed</div></div>
    <div class="card stat-card"><div class="num">${myMatches.length}</div><div class="label">Potential matches</div></div>
    <div class="card stat-card"><div class="num">${resolved}</div><div class="label">Cases resolved</div></div>
  </div>

  <div class="section-title">Quick actions</div>
  <div class="grid grid-3">
    <div class="card" style="cursor:pointer;" data-route="report-lost"><h4 style="margin:0 0 6px;">📄 Report a lost item</h4><div class="meta" style="color:var(--text-dim);font-size:12.5px;">Describe what you lost and where</div></div>
    <div class="card" style="cursor:pointer;" data-route="report-found"><h4 style="margin:0 0 6px;">📦 Report a found item</h4><div class="meta" style="color:var(--text-dim);font-size:12.5px;">Log an item so we can find its owner</div></div>
    <div class="card" style="cursor:pointer;" data-route="matches"><h4 style="margin:0 0 6px;">⇄ Check potential matches</h4><div class="meta" style="color:var(--text-dim);font-size:12.5px;">See ranked matches for your reports</div></div>
  </div>

  <div class="section-title">Recent activity on your reports</div>
  ${
    [...myLost, ...myFound]
      .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
      .slice(0, 5)
      .map((r) => renderItemCard(r, myLost.includes(r) ? "lost" : "found"))
      .join("") ||
    `<div class="empty-state"><div class="ico">📭</div>No reports yet — file your first one above.</div>`
  }
  `;
}
function bindDashboard() {
  document.querySelectorAll("[data-route]").forEach((el) => {
    el.onclick = () => go(el.dataset.route);
  });
}

/* ---------------- REPORT FORMS ---------------- */
function renderReportForm(kind) {
  const isLost = kind === "lost";
  return `
  <div class="card" style="max-width:640px;">
    <div class="field-cols">
      <div class="field"><label>Category</label>
        <select id="f-category">${DB.categories.map((c) => `<option>${c}</option>`).join("")}</select>
      </div>
      <div class="field"><label>Brand / Model</label><input id="f-brand" placeholder="e.g. Dell XPS 13"></div>
    </div>
    <div class="field-cols">
      <div class="field"><label>Color</label><input id="f-color" placeholder="e.g. Black"></div>
      <div class="field"><label>${isLost ? "Date/time lost" : "Date/time found"}</label><input id="f-datetime" type="datetime-local"></div>
    </div>
    <div class="field"><label>Location (building &amp; room)</label>
      <select id="f-location">${DB.locations.map((l) => `<option value="${l.id}">${l.building} — ${l.room}</option>`).join("")}</select>
    </div>
    ${
      !isLost
        ? `<div class="field"><label>Storage location (where the item is being kept)</label>
      <select id="f-storage">${DB.storages.map((s) => `<option value="${s.id}">${s.name}</option>`).join("")}</select>
    </div>`
        : ""
    }
    <div class="field"><label>Description &amp; unique features</label>
      <textarea id="f-desc" placeholder="Distinctive marks, contents, scratches, stickers, etc."></textarea>
    </div>
    <div class="field"><label>Photo (optional — description only in this prototype)</label>
      <input id="f-photo" placeholder="e.g. photo_laptop_crack.jpg"></div>
    <button class="btn btn-primary" id="submit-report">Submit ${isLost ? "Lost" : "Found"} Report</button>
  </div>`;
}
function bindReportForm(kind) {
  const isLost = kind === "lost";
  document.getElementById("submit-report").onclick = guard(async () => {
    const category = document.getElementById("f-category").value;
    const brand = document.getElementById("f-brand").value.trim();
    const color = document.getElementById("f-color").value.trim();
    const datetime = document.getElementById("f-datetime").value;
    const locationId = document.getElementById("f-location").value;
    const description = document.getElementById("f-desc").value.trim();
    if (!description) {
      toast("Please add a description — it drives match accuracy.");
      return;
    }
    const catRow = ((RAW && RAW.category) || []).find(
      (c) => c.category_name === category,
    );
    if (!catRow) {
      toast("Please choose a category.");
      return;
    }
    const date = datetime ? datetime.slice(0, 10) : todayStr(); // tables store a DATE

    // 1) the physical item  2) the lost/found report that points to it
    const itemId = await dbInsert("item", {
      item_name: clip(brand || category, 100),
      category_id: catRow.category_id,
      description,
      color: clip(color, 50) || null,
      brand: clip(brand, 100) || null,
    });
    const table = isLost ? "lost_report" : "found_report";
    const data = {
      item_id: itemId,
      location_id: N(locationId),
      description: clip(description, 255),
    };
    if (isLost) {
      data.lost_date = date;
    } else {
      data.found_date = date;
      data.storage_id = N(document.getElementById("f-storage").value);
    }
    const newId = await dbInsert(table, data);
    await addAudit(
      isLost ? "Submitted Lost Report" : "Submitted Found Report",
      table,
      newId,
    );

    await loadState();
    const rec = (isLost ? DB.lostReports : DB.foundReports).find(
      (r) => r.id === S(newId),
    );
    if (rec) await recomputeMatches(rec, kind);
    await loadState();
    toast(`${isLost ? "Lost" : "Found"} report submitted.`);
    go("my-items");
  });
}

/* ---------------- MY ITEMS ---------------- */
function renderItemCard(r, kind) {
  const isLost = kind === "lost";
  return `<div class="item-card" style="margin-bottom:10px;">
    <div class="row-top">
      <div>
        <h4>${isLost ? "🔎" : "📦"} ${r.category}${r.brand ? " — " + r.brand : ""}</h4>
        <div class="meta">${locName(r.locationId)} · ${fmtDate(r.datetime)}${r.storageId ? " · stored at " + storageName(r.storageId) : ""}</div>
      </div>
      ${badge(r.status)}
    </div>
    <div class="desc">${r.description}</div>
    <div class="actions">
      ${r.status === "Open" && r.userId === ui.currentUserId ? `<button class="btn btn-sm btn-danger" data-withdraw="${r.id}" data-kind="${isLost ? "lost" : "found"}">Withdraw</button>` : ""}
    </div>
  </div>`;
}
function renderMyItems() {
  const u = currentUser();
  const myLost = DB.lostReports.filter((r) => r.userId === u.id);
  const myFound = DB.foundReports.filter((r) => r.userId === u.id);
  return `
  <div class="section-title">Lost reports (${myLost.length})</div>
  ${myLost.length ? myLost.map((r) => renderItemCard(r, "lost")).join("") : `<div class="empty-state">No lost reports yet.</div>`}
  <div class="section-title">Found reports (${myFound.length})</div>
  ${myFound.length ? myFound.map((r) => renderItemCard(r, "found")).join("") : `<div class="empty-state">No found reports yet.</div>`}
  `;
}
function bindMyItems() {
  document.querySelectorAll("[data-withdraw]").forEach((b) => {
    b.onclick = guard(async () => {
      const table = b.dataset.kind === "lost" ? "lost_report" : "found_report";
      await dbUpdate(table, b.dataset.withdraw, { status: "closed" });
      await addAudit("Withdrew report", table, b.dataset.withdraw);
      await persist();
      toast("Report withdrawn.");
    });
  });
}

/* ---------------- MATCHES ---------------- */
function scoreColor(score) {
  if (score >= 75)
    return "background:var(--success-soft);color:var(--success);border:1px solid var(--success);";
  if (score >= 45)
    return "background:var(--warn-soft);color:var(--warn);border:1px solid var(--warn);";
  return "background:var(--panel-3);color:var(--text-dim);border:1px solid var(--border);";
}
function renderMatches() {
  const u = currentUser();
  const relevant = DB.matches
    .filter((m) => {
      const lr = DB.lostReports.find((x) => x.id === m.lostReportId);
      const fr = DB.foundReports.find((x) => x.id === m.foundReportId);
      return (
        isStaff() || (lr && lr.userId === u.id) || (fr && fr.userId === u.id)
      );
    })
    .sort((a, b) => b.score - a.score);

  if (!relevant.length)
    return `<div class="empty-state"><div class="ico">🕵️</div>No suitable match yet. Cases stay open and are re-checked automatically whenever a new report comes in.</div>`;

  return relevant
    .map((m) => {
      const lr = DB.lostReports.find((x) => x.id === m.lostReportId);
      const fr = DB.foundReports.find((x) => x.id === m.foundReportId);
      const alreadyClaimed = DB.claims.find(
        (c) => c.matchId === m.id && c.claimantId === u.id,
      );
      return `
    <div class="match-row">
      <div class="score-ring" style="${scoreColor(m.score)}">${m.score}%</div>
      <div style="flex:1;">
        <div style="font-weight:600;font-size:13.5px;">${lr ? lr.category + (lr.brand ? " — " + lr.brand : "") : "—"} <span style="color:var(--text-dim);font-weight:400;">↔</span> ${fr ? fr.category + (fr.brand ? " — " + fr.brand : "") : "—"}</div>
        <div class="meta">Lost by ${userName(lr?.userId)} at ${locName(lr?.locationId)} · Found by ${userName(fr?.userId)} at ${locName(fr?.locationId)}</div>
        <div style="margin-top:6px;">${badge(m.status)}</div>
      </div>
      <div class="actions">
        ${!alreadyClaimed && lr && lr.userId === u.id && m.status !== "Approved" ? `<button class="btn btn-sm btn-primary" data-claim="${m.id}">Submit Claim</button>` : ""}
        ${isStaff() && m.status === "Suggested" ? `<button class="btn btn-sm" data-force="${m.id}">Force Confirm</button>` : ""}
      </div>
    </div>`;
    })
    .join("");
}
function bindMatches() {
  document.querySelectorAll("[data-claim]").forEach((b) => {
    b.onclick = () => openClaimModal(b.dataset.claim);
  });
  document.querySelectorAll("[data-force]").forEach((b) => {
    b.onclick = guard(async () => {
      await dbUpdate("match_record", b.dataset.force, { status: "confirmed" });
      await addAudit("Staff force-confirmed match", "match_record", b.dataset.force);
      await persist();
      toast("Match confirmed by staff.");
    });
  });
}
function openClaimModal(matchId) {
  const m = DB.matches.find((x) => x.id === matchId);
  const modal = document.createElement("div");
  modal.className = "modal-bg";
  modal.innerHTML = `
  <div class="modal">
    <h3>Submit Ownership Claim</h3>
    <div class="meta" style="margin-bottom:10px;">These details are private — only visible to staff during review, never shown publicly.</div>
    <div class="private-box">
      <div class="field"><label>Serial number / unique mark</label><textarea id="cl-priv" placeholder="e.g. serial ends in 7X4K, scratch under the lid..."></textarea></div>
      <div class="field"><label>Supporting evidence (receipt, photo description, etc.)</label><textarea id="cl-evid" placeholder="e.g. purchase receipt from..."></textarea></div>
    </div>
    <div style="display:flex;gap:10px;justify-content:flex-end;">
      <button class="btn" id="cl-cancel">Cancel</button>
      <button class="btn btn-primary" id="cl-submit">Submit Claim</button>
    </div>
  </div>`;
  document.body.appendChild(modal);
  modal.querySelector("#cl-cancel").onclick = () => modal.remove();
  modal.querySelector("#cl-submit").onclick = guard(async () => {
    const priv = modal.querySelector("#cl-priv").value.trim();
    const evid = modal.querySelector("#cl-evid").value.trim();
    if (!priv) {
      toast("Please provide at least one private identifying detail.");
      return;
    }
    const claimId = await dbInsert("claim", {
      match_id: N(matchId),
      claim_description: clip(priv, 255),
    });
    if (evid)
      await dbInsert("evidence", {
        claim_id: claimId,
        evidence_type: "Ownership Proof",
        evidence_description: clip(evid, 255),
        is_private: 1,
      });
    await addAudit("Submitted Claim", "claim", claimId);
    // notify staff
    for (const s of DB.users.filter(isStaffRole))
      await notify(
        s.id,
        `New claim submitted by ${plainUserName(ui.currentUserId)} — needs review.`,
        "Claim Submitted",
      );
    modal.remove();
    await persist();
    toast("Claim submitted for staff review.");
  });
}

/* ---------------- NOTIFICATIONS PAGE ---------------- */
function renderNotificationsPage() {
  const list = myNotifs();
  return list.length
    ? list
        .map(
          (n) =>
            `<div class="item-card" style="margin-bottom:8px;"><div>${n.text}</div><div class="meta">${fmtDate(n.createdAt)}</div></div>`,
        )
        .join("")
    : `<div class="empty-state"><div class="ico">🔔</div>Nothing here yet.</div>`;
}

/* ---------------- STAFF: REVIEW CLAIMS ---------------- */
function renderStaffReview() {
  const pending = DB.claims.filter((c) => c.status === "Pending");
  if (!pending.length)
    return `<div class="empty-state"><div class="ico">✅</div>No pending claims — all caught up.</div>`;
  return pending
    .map((c) => {
      const m = DB.matches.find((x) => x.id === c.matchId);
      const fr = DB.foundReports.find((x) => x.id === m.foundReportId);
      const lr = DB.lostReports.find((x) => x.id === m.lostReportId);
      const otherClaims = DB.claims.filter(
        (x) =>
          x.matchId === c.matchId && x.id !== c.id && x.status === "Pending",
      );
      return `
    <div class="card" style="margin-bottom:16px;">
      <div class="row-top" style="margin-bottom:10px;">
        <h4 style="margin:0;">Claim on: ${fr.category}${fr.brand ? " — " + fr.brand : ""} <span style="color:var(--text-dim);font-weight:400;font-size:12px;">(match score ${m.score}%)</span></h4>
        ${badge(c.status)}
      </div>
      <div class="grid grid-2">
        <div class="card" style="background:var(--panel-2);">
          <div class="meta" style="margin-bottom:6px;">FOUND ITEM (public post)</div>
          <div style="font-size:13px;">${fr.description}</div>
          <div class="meta" style="margin-top:8px;">Stored at ${storageName(fr.storageId)} · Reported by ${userName(fr.userId)}</div>
        </div>
        <div class="card" style="background:var(--panel-2);border:1px dashed var(--accent);">
          <div class="meta" style="margin-bottom:6px;">CLAIMANT EVIDENCE — ${userName(c.claimantId)}</div>
          <div style="font-size:13px;"><strong>Private detail:</strong> ${c.privateEvidence}</div>
          ${c.evidenceNote ? `<div style="font-size:13px;margin-top:6px;"><strong>Supporting evidence:</strong> ${c.evidenceNote}</div>` : ""}
        </div>
      </div>
      ${otherClaims.length ? `<div class="private-box" style="border-color:var(--danger);margin-top:12px;">⚠ ${otherClaims.length} other pending claim(s) on the same item — potential dispute. Consider opening an investigation.</div>` : ""}
      <div class="field" style="margin-top:12px;"><label>Decision reason</label><textarea id="reason-${c.id}" placeholder="Explain why this claim is approved or rejected"></textarea></div>
      <div class="actions">
        <button class="btn btn-success" data-approve="${c.id}">Approve Claim</button>
        <button class="btn btn-danger" data-reject="${c.id}">Reject Claim</button>
        ${otherClaims.length ? `<button class="btn" data-investigate="${c.id}">Open Investigation</button>` : ""}
      </div>
    </div>`;
    })
    .join("");
}
function bindStaffReview() {
  document.querySelectorAll("[data-approve]").forEach((b) => {
    b.onclick = guard(async () => {
      const c = DB.claims.find((x) => x.id === b.dataset.approve);
      const reason =
        document.getElementById("reason-" + c.id).value.trim() ||
        "Evidence matched found item.";
      const m = DB.matches.find((x) => x.id === c.matchId);
      const fr = DB.foundReports.find((x) => x.id === m.foundReportId);
      await dbUpdate("claim", c.id, { claim_status: "approved" });
      await dbUpdate("match_record", m.id, { status: "confirmed" });
      if (fr) await dbUpdate("found_report", fr.id, { status: "claimed" });
      // auto-reject other pending claims on the same match
      const others = DB.claims.filter(
        (x) => x.matchId === c.matchId && x.id !== c.id && x.status === "Pending",
      );
      for (const x of others) {
        await dbUpdate("claim", x.id, { claim_status: "rejected" });
        await addAudit(
          "Rejected Claim",
          "claim",
          x.id,
          "Another claimant's evidence was verified.",
        );
        await notify(
          x.claimantId,
          "Your claim was rejected — another claimant's evidence was verified.",
          "Claim Rejected",
        );
      }
      await addAudit("Approved Claim", "claim", c.id, reason); // reason lives in audit_log
      await notify(
        c.claimantId,
        "Your claim was approved! Visit the security office to arrange handover.",
        "Claim Approved",
      );
      if (fr)
        await notify(
          fr.userId,
          "The item you found has been claimed and verified.",
          "Item Claimed",
        );
      await persist();
      toast("Claim approved.");
    });
  });
  document.querySelectorAll("[data-reject]").forEach((b) => {
    b.onclick = guard(async () => {
      const c = DB.claims.find((x) => x.id === b.dataset.reject);
      const reason =
        document.getElementById("reason-" + c.id).value.trim() ||
        "Evidence did not match.";
      await dbUpdate("claim", c.id, { claim_status: "rejected" });
      await addAudit("Rejected Claim", "claim", c.id, reason);
      await notify(c.claimantId, "Your claim was rejected. Reason: " + reason, "Claim Rejected");
      await persist();
      toast("Claim rejected.");
    });
  });
  document.querySelectorAll("[data-investigate]").forEach((b) => {
    b.onclick = guard(async () => {
      if (!b.dataset.investigate) return;
      const id = await dbInsert("investigation", {
        claim_id: N(b.dataset.investigate),
        investigator_id: N(ui.currentUserId),
        investigation_date: todayStr(),
        investigation_status: "open",
        findings: "Multiple claimants on same item",
      });
      await addAudit("Opened investigation (dispute)", "investigation", id);
      await persist();
      toast("Investigation opened.");
      go("investigations");
    });
  });
}

/* ---------------- INVESTIGATIONS ---------------- */
function renderInvestigations() {
  if (!DB.investigations.length)
    return `
    <div class="card" style="margin-bottom:16px;">
      <h4 style="margin-top:0;">Open a new investigation</h4>
      <div class="field"><label>Related lost report</label>
        <select id="inv-lr">${investigableLostReports().map((r) => `<option value="${r.id}">${r.category} — ${r.brand || ""} (${userName(r.userId)})</option>`).join("")}</select>
      </div>
      <div class="field"><label>Reason</label><textarea id="inv-reason" placeholder="Why is an investigation needed?"></textarea></div>
      <button class="btn btn-primary" id="inv-open">Open Investigation</button>
    </div>
    <div class="empty-state"><div class="ico">🗂️</div>No investigations yet.</div>`;

  return `
  <div class="card" style="margin-bottom:16px;">
    <h4 style="margin-top:0;">Open a new investigation</h4>
    <div class="field"><label>Related lost report</label>
      <select id="inv-lr">${investigableLostReports().map((r) => `<option value="${r.id}">${r.category} — ${r.brand || ""} (${userName(r.userId)})</option>`).join("")}</select>
    </div>
    <div class="field"><label>Reason</label><textarea id="inv-reason" placeholder="Why is an investigation needed?"></textarea></div>
    <button class="btn btn-primary" id="inv-open">Open Investigation</button>
  </div>
  ${DB.investigations
    .map((inv) => {
      const lr = DB.lostReports.find((x) => x.id === inv.lostReportId);
      const witnesses = DB.witnessReports.filter(
        (w) => w.investigationId === inv.id,
      );
      const cctv = DB.cctvRefs.filter((c) => c.investigationId === inv.id);
      return `
    <div class="card" style="margin-bottom:16px;">
      <div class="row-top">
        <h4 style="margin:0;">Case: ${lr ? lr.category + " — " + (lr.brand || "") : "—"}</h4>
        ${badge(inv.status)}
      </div>
      <div class="meta">Opened by ${userName(inv.openedBy)} · ${fmtDate(inv.createdAt)}</div>
      <div class="desc" style="margin:8px 0;">${inv.reason}</div>
      <div class="divider"></div>
      <div class="grid grid-2">
        <div>
          <div class="meta" style="margin-bottom:6px;">WITNESS REPORTS</div>
          ${witnesses.map((w) => `<div class="log-item"><div>${w.statement}</div><div class="when">at ${locName(w.locationId)}</div></div>`).join("") || `<div class="meta">None yet</div>`}
          <div class="field" style="margin-top:10px;"><textarea id="wit-${inv.id}" placeholder="Add witness statement..."></textarea></div>
          <div class="field"><select id="wit-loc-${inv.id}">${DB.locations.map((l) => `<option value="${l.id}">${l.building} — ${l.room}</option>`).join("")}</select></div>
          <button class="btn btn-sm" data-add-witness="${inv.id}">Add Witness Report</button>
        </div>
        <div>
          <div class="meta" style="margin-bottom:6px;">CCTV REFERENCES</div>
          ${cctv.map((c) => `<div class="log-item"><div>${(DB.cameras.find((x) => x.id === c.cameraId) || {}).label || c.cameraId}</div><div class="when">${c.timeWindow}</div></div>`).join("") || `<div class="meta">None yet</div>`}
          <div class="field" style="margin-top:10px;"><select id="cctv-cam-${inv.id}">${DB.cameras.map((c) => `<option value="${c.id}">${c.label}</option>`).join("")}</select></div>
          <div class="field"><input id="cctv-window-${inv.id}" placeholder="Time window e.g. 2:00–2:30 PM"></div>
          <button class="btn btn-sm" data-add-cctv="${inv.id}">Add CCTV Reference</button>
        </div>
      </div>
      ${inv.status === "Open" ? `<button class="btn btn-success" style="margin-top:14px;" data-close-inv="${inv.id}">Close Investigation</button>` : ""}
    </div>`;
    })
    .join("")}
  `;
}
function bindInvestigations() {
  const openBtn = document.getElementById("inv-open");
  if (openBtn)
    openBtn.onclick = guard(async () => {
      const lostReportId = document.getElementById("inv-lr").value;
      const reason = document.getElementById("inv-reason").value.trim();
      if (!reason) {
        toast("Please describe the reason for investigation.");
        return;
      }
      const claim = claimForLostReport(lostReportId);
      if (!claim) {
        toast("That lost report has no claim yet — an investigation is linked to a claim.");
        return;
      }
      const id = await dbInsert("investigation", {
        claim_id: N(claim.id),
        investigator_id: N(ui.currentUserId),
        investigation_date: todayStr(),
        investigation_status: "open",
        findings: clip(reason, 500),
      });
      await addAudit("Opened investigation", "investigation", id);
      await persist();
      toast("Investigation opened.");
    });
  document.querySelectorAll("[data-add-witness]").forEach((b) => {
    b.onclick = guard(async () => {
      const id = b.dataset.addWitness;
      const statement = document.getElementById("wit-" + id).value.trim();
      const locationId = document.getElementById("wit-loc-" + id).value;
      if (!statement) {
        toast("Enter a statement first.");
        return;
      }
      const suffix = ` [at: ${rawLocLabel(locationId)}]`;
      const wid = await dbInsert("witness_report", {
        investigation_id: N(id),
        witness_name: "Unnamed witness",
        witness_statement: clip(statement, 500 - suffix.length) + suffix,
        report_date: todayStr(),
      });
      await addAudit("Added witness report", "witness_report", wid);
      await persist();
    });
  });
  document.querySelectorAll("[data-add-cctv]").forEach((b) => {
    b.onclick = guard(async () => {
      const id = b.dataset.addCctv;
      const cameraId = document.getElementById("cctv-cam-" + id).value;
      const timeWindow = document
        .getElementById("cctv-window-" + id)
        .value.trim();
      if (!timeWindow) {
        toast("Enter a time window first.");
        return;
      }
      const inv = DB.investigations.find((x) => x.id === id);
      const lr = inv && DB.lostReports.find((x) => x.id === inv.lostReportId);
      const { start, end } = parseTimeWindow(timeWindow);
      const cid = await dbInsert("cctv_ref", {
        investigation_id: N(id),
        camera_id: N(cameraId),
        footage_date: lr ? lr.datetime : todayStr(), // footage of the day it was lost
        start_time: start,
        end_time: end,
        description: clip(timeWindow, 255),
      });
      await addAudit("Added CCTV reference", "cctv_ref", cid);
      await persist();
    });
  });
  document.querySelectorAll("[data-close-inv]").forEach((b) => {
    b.onclick = guard(async () => {
      await dbUpdate("investigation", b.dataset.closeInv, {
        investigation_status: "closed",
      });
      await addAudit("Closed investigation", "investigation", b.dataset.closeInv);
      await persist();
      toast("Investigation closed.");
    });
  });
}

/* ---------------- CUSTODY & HANDOVER ---------------- */
function renderCustody() {
  const approvedClaims = DB.claims.filter(
    (c) =>
      c.status === "Approved" && !DB.handovers.find((h) => h.claimId === c.id),
  );
  return `
  <div class="section-title">Pending handovers</div>
  ${
    approvedClaims.length
      ? approvedClaims
          .map((c) => {
            const m = DB.matches.find((x) => x.id === c.matchId);
            const fr = DB.foundReports.find((x) => x.id === m.foundReportId);
            return `<div class="item-card" style="margin-bottom:10px;">
      <div class="row-top">
        <h4>${fr.category} — ${fr.brand || ""}</h4>
        <span class="badge badge-approved">Approved</span>
      </div>
      <div class="meta">Claimant: ${userName(c.claimantId)} · Currently at ${storageName(fr.storageId)}</div>
      <div class="actions">
        <input id="recipient-${c.id}" placeholder="Recipient name" style="max-width:200px;">
        <button class="btn btn-success btn-sm" data-handover="${c.id}">Record Handover</button>
      </div>
    </div>`;
          })
          .join("")
      : `<div class="empty-state">No pending handovers.</div>`
  }

  <div class="section-title">Custody log</div>
  ${
    DB.custodyEvents
      .slice()
      .reverse()
      .map(
        (ce) => `
    <div class="log-item">
      <div>${ce.itemRef} moved ${ce.fromStorage ? "from " + storageName(ce.fromStorage) : ""} to ${storageName(ce.toStorage)} — handled by ${userName(ce.staffId)}</div>
      <div class="when">${fmtDate(ce.timestamp)}</div>
    </div>`,
      )
      .join("") || `<div class="empty-state">No custody events logged.</div>`
  }
  `;
}
function bindCustody() {
  document.querySelectorAll("[data-handover]").forEach((b) => {
    b.onclick = guard(async () => {
      const c = DB.claims.find((x) => x.id === b.dataset.handover);
      const typed = document.getElementById("recipient-" + c.id).value.trim();
      const m = DB.matches.find((x) => x.id === c.matchId);
      const fr = DB.foundReports.find((x) => x.id === m.foundReportId);
      // handover.handed_over_to is a user id: use the typed name if it is a
      // registered user, otherwise the claimant (typed name goes in notes)
      const ru = ((RAW && RAW.user) || []).find(
        (u) => typed && u.name.toLowerCase() === typed.toLowerCase(),
      );
      const hid = await dbInsert("handover", {
        claim_id: N(c.id),
        handed_over_by: N(ui.currentUserId),
        handed_over_to: N(ru ? ru.user_id : c.claimantId),
        handover_status: "completed",
        notes:
          typed && !ru
            ? clip(`Recipient name given: ${typed}`, 255)
            : "Handed over after staff verification.",
      });
      await dbUpdate("lost_report", m.lostReportId, { status: "closed" });
      if (fr) {
        await dbUpdate("found_report", fr.id, { status: "closed" });
        await dbInsert("custody_event", {
          found_report_id: N(fr.id),
          storage_id: N(fr.storageId),
          event_type: "released",
          notes: "Released to claimant at handover.",
        });
      }
      await addAudit("Recorded Handover", "handover", hid);
      await notify(c.claimantId, "Your item has been handed over. Case closed.", "Handover");
      await persist();
      toast("Handover recorded — case resolved.");
    });
  });
}

/* ---------------- ANALYTICS ---------------- */
function renderAnalytics() {
  const totalLost = DB.lostReports.length;
  const totalFound = DB.foundReports.length;
  const matched = DB.matches.length;
  const recovered = DB.lostReports.filter(
    (r) => r.status === "Resolved",
  ).length;
  const recoveryRate = totalLost
    ? Math.round((recovered / totalLost) * 100)
    : 0;

  const byCategory = {};
  DB.categories.forEach((c) => (byCategory[c] = 0));
  [...DB.lostReports, ...DB.foundReports].forEach((r) => {
    if (byCategory[r.category] !== undefined) byCategory[r.category]++;
  });

  return `
  <div class="grid grid-4">
    <div class="card stat-card"><div class="num">${totalLost}</div><div class="label">Total lost reports</div></div>
    <div class="card stat-card"><div class="num">${totalFound}</div><div class="label">Total found reports</div></div>
    <div class="card stat-card"><div class="num">${matched}</div><div class="label">Matches generated</div></div>
    <div class="card stat-card"><div class="num" style="color:var(--success);">${recoveryRate}%</div><div class="label">Recovery rate (${recovered}/${totalLost})</div></div>
  </div>

  <div class="section-title">Reports by category</div>
  <div class="card">
    ${Object.entries(byCategory)
      .map(([cat, count]) => {
        const max = Math.max(1, ...Object.values(byCategory));
        const pct = Math.round((count / max) * 100);
        return `<div style="margin-bottom:10px;">
        <div style="display:flex;justify-content:space-between;font-size:12.5px;margin-bottom:4px;"><span>${cat}</span><span style="color:var(--text-dim);">${count}</span></div>
        <div class="progress-bar"><div style="width:${pct}%;"></div></div>
      </div>`;
      })
      .join("")}
  </div>

  <div class="section-title">Case status breakdown</div>
  <div class="grid grid-4">
    ${["Open", "Matched", "Claimed", "Resolved"]
      .map((status) => {
        const c = [...DB.lostReports, ...DB.foundReports].filter(
          (r) => r.status === status,
        ).length;
        return `<div class="card stat-card"><div class="num">${c}</div><div class="label">${status}</div></div>`;
      })
      .join("")}
  </div>
  `;
}

/* ---------------- AUDIT LOG ---------------- */
function renderAuditLog() {
  return `<div class="card">
    ${DB.auditLog
      .slice(0, 80)
      .map(
        (a) => `
      <div class="log-item">
        <div><strong>${userName(a.userId)}</strong> — ${a.action} <span style="color:var(--text-dim);">(${a.entityRef})</span></div>
        <div class="when">${fmtDate(a.timestamp)}</div>
      </div>`,
      )
      .join("")}
  </div>`;
}

/* ---------------- USERS (staff) ---------------- */
function renderUsers() {
  return `
  <div class="card" style="margin-bottom:16px;">
    <div class="grid grid-3">
      <div class="field"><label>Name</label><input id="nu-name"></div>
      <div class="field"><label>Email</label><input id="nu-email"></div>
      <div class="field"><label>Role</label><select id="nu-role"><option value="student">Student</option><option value="staff">Staff</option></select></div>
    </div>
    <button class="btn btn-primary btn-sm" id="add-user">Add User</button>
  </div>
  ${DB.users
    .map(
      (u) => `
    <div class="item-card" style="margin-bottom:8px;">
      <div class="row-top">
        <div><h4>${u.name}</h4><div class="meta">${u.email} · ${u.contact || "—"}</div></div>
        <span class="badge badge-open" style="text-transform:capitalize;">${u.role}</span>
      </div>
    </div>`,
    )
    .join("")}
  `;
}
function bindUsers() {
  document.getElementById("add-user").onclick = guard(async () => {
    const name = document.getElementById("nu-name").value.trim();
    const email = document.getElementById("nu-email").value.trim();
    const role = document.getElementById("nu-role").value;
    if (!name || !email) {
      toast("Name and email required.");
      return;
    }
    const id = await dbInsert("user", {
      name: clip(name, 100),
      email: clip(email, 150),
      role,
    });
    await addAudit("Admin added user", "user", id);
    await persist();
    toast("User added.");
  });
}

/* ---------------- PROFILE ---------------- */
function renderProfile() {
  const u = currentUser();
  return `
  <div class="card" style="max-width:480px;">
    <div class="field"><label>Full name</label><input id="pr-name" value="${u.name}"></div>
    <div class="field"><label>Email</label><input id="pr-email" value="${u.email}"></div>
    <div class="field"><label>Contact info</label><input id="pr-contact" value="${u.contact || ""}"></div>
    <div class="field"><label>Role</label><input value="${u.role}" disabled style="text-transform:capitalize;opacity:.6;"></div>
    <div class="field"><label>New password (optional)</label><input type="password" id="pr-pass" placeholder="Leave blank to keep current"></div>
    <button class="btn btn-primary" id="save-profile">Save Changes</button>
  </div>`;
}
function bindProfile() {
  document.getElementById("save-profile").onclick = guard(async () => {
    const u = currentUser();
    const me = RAW.me;
    const data = {
      name: clip(document.getElementById("pr-name").value.trim() || me.name, 100),
      email: clip(document.getElementById("pr-email").value.trim() || me.email, 150),
      phone: clip(document.getElementById("pr-contact").value.trim(), 20) || null,
    };
    const pass = document.getElementById("pr-pass").value;
    if (pass) data.password = pass; // api.php hashes it
    await dbUpdate("user", u.id, data);
    await addAudit("Updated profile", "user", u.id);
    await persist();
    toast("Profile updated.");
  });
}

document.addEventListener("click", (e) => {
  if (
    ui.notifOpen &&
    !e.target.closest(".notif-panel") &&
    !e.target.closest("#bell-btn")
  ) {
    ui.notifOpen = false;
    render();
  }
});

init();
